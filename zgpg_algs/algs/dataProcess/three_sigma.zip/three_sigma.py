import numpy as np


def algsMain(*args, **kwargs):

    try:

        time = args[0]
        data = args[1]

        count = 5
        data_size = len(data)
        while count > 0:
            time, data = iter_three_sigma(time, data)
            if len(data) == data_size:
                break
            else:
                data_size = len(data)
            count -= 1

        return True, [time, data]
    except Exception as e:
        return False, e.args


def iter_three_sigma(time, data):
    data = np.array(data)
    average = np.nanmean(data)
    std = np.nanstd(data)
    index = np.where((data > (average + 3 * std)) | (data < (average - 3 * std)) | (np.abs(data) > 10000))
    data = data.tolist()
    for idx in range(len(index[0]) - 1, -1, -1):
        del time[index[0][idx]]
        del data[index[0][idx]]
    return time, data


if __name__ == "__main__":
    time = [1691100000, 1691100001, 1691100002, 1691100003]
    data = [11,12,11,15]
    print(algsMain(time, data)[1])


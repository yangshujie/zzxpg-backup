import pandas as pd
import numpy as np


def algsMain(*args, **kwargs):
    '''
    填充或剔除
    :param dataframes:
    :return:
    '''
    dataframes = args[0]
    try:
        # data = pd.merge(data1,data2,how="outer",left_index=True,right_index=True)
        res_merge = dataframes[0]
        for idx, item in enumerate(dataframes):
            if idx == 0:
                continue
            res_merge = pd.merge(res_merge, item, how="outer", left_index=True, right_index=True)
            # with open("C:/Users/TGKY/Desktop/23.txt","w") as f:
            #     f.write(str(list(res_merge.index)))

        # res_merge = reduce(lambda left, right: pd.merge(left, right, how="outer", left_index=True, right_index=True),
        #                    dataframes)
        res_merge.replace([np.inf, -np.inf], np.nan, inplace=True)
        res_merge = res_merge.fillna(method="ffill")
        res_merge = res_merge.dropna(how="any")  # 报错
        return True, res_merge
    except Exception as e:
        return False, e.args
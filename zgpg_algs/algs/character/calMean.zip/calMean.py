#coding: utf-8

import pandas as pd
import numpy as np
import requests
import json,time,math

# [[[time],[data1],[data2]],[]]

def algsMain(*args,**kwargs):
    '''
    均值
    :param args:
    :param kwargs:
    :return:
    '''
    try:
        rst = []

        datas = args[0]
        all_days_datas = [np.asarray(item[1:]) for item in datas]
        # print(datas)
        for idx,every_day_data in enumerate(all_days_datas):
            # todaytimes=datas[idx][0]
            if len(every_day_data[0]) == 0:
                rst.append("null")
            else:
                tmpdata = every_day_data[0]
                for i in range(1,len(every_day_data)):
                    tmpdata+=every_day_data[i]
                if len(tmpdata) != 0:
                    rst.append(np.nanmean(tmpdata) / len(every_day_data))
                else:
                    rst.append("null")

        return True,rst
    except Exception as e:
        return False,e.args


# 1678204799
if __name__ == '__main__':
    args=[[[1678118400,1678118401,1678118402,1678118403,1678118404,1678118405,1678118406,1678118407,1678118410,1678118412],[2,2,2,2,2,2,2,2,2,2],[2,2,2,2,2,2,2,2,2,2],[2,2,2,2,2,2,2,2,2,2]],
     [[1678118400,1678118401,1678118402,1678118403,1678118404,1678118405,1678118406,1678118407,1678118408,1678204799],[2,2,2,2,2,2,2,2,2,2],[2,2,2,2,2,2,2,2,2,2],[2,2,2,2,2,2,2,2,2,2]],
          [[],[],[],[]]]
    kwargs={}
    status,rst=algsMain(args,*kwargs)
    print(rst)

import requests
import numpy as np
import datetime
import math
import time

def algsMain(*args, **kwargs):
    '''
    计算轨控精度
    :param args:
    :param kwargs:
    :return:
    '''
    # data = {
    #     "taskCode": "BD3G01",
    #     "startTime":"2018-12-25 15:29:47",
    #     "endTime":"2019-12-25 15:29:47"
    # }
    try:
        print('计算轨控精度')
        config = kwargs["config"]
        start_time = config["zgpg_start_time"]
        end_time = config["zgpg_end_time"]
        sattype = config["sat_type"]
        result_list = calMain(sattype, start_time, end_time, config)

        print('轨控精度计算完成')
        return True,result_list
    except Exception as e:
        return False,e.args

def calMain(sattype, starttime, endtime, config):
    result_list = []
    start_date = str_to_datetime(starttime)
    end_date = str_to_datetime(endtime)
    days = (end_date - start_date).days
    data = {
        "taskCode": sattype.split("-")[0]
    }
    rsp = requests.get(url=config["url"], params=data)
    result = eval(rsp.text)["datas"]
    if len(result) == 0:
        for day in range(days + 1):
            result_list.append("null")
    else:
        result = [item for item in result if item["flameouttime"] != "" and item["flameouttime"] is not None]
        result = sorted(result, key=lambda x: str_to_datetime(x["flameouttime"]), reverse=True)
        control_precision_list = []
        flag = True
        for day in range(days + 1):
            current_day = start_date + datetime.timedelta(days=1)
            for item in result:
                if start_date < str_to_datetime(item["flameouttime"]):
                    if str_to_datetime(item["flameouttime"]) < current_day:
                        flag = False
                        control_precision = item["controlprecision"]
                        control_precision_list.append(control_precision)
                else:
                    flag = False
                    if control_precision_list:
                        result_list.append(np.mean(control_precision_list))
                    else:
                        result_list.append(item["controlprecision"])
                    control_precision_list.clear()
                    break
            if control_precision_list:
                result_list.append(np.mean(control_precision_list))
                control_precision_list.clear()
            # start_date = start_date + datetime.timedelta(days=1)
            # 往前取最近的但没有记录的情况
            if flag:
                # if len(result) > 0:
                #     result_list.append(result[-1]["controlprecision"])
                # else:
                #     result_list.append(100)
                result_list.append('null')
            start_date = start_date + datetime.timedelta(days=1)
        # result_list = list(np.array(result_list) / 100.0)
    result_list_new = result_list.copy()
    for res in result_list:
        if res == 'null':
            result_list_new.append(1)
        else:
            result_list_new.append(res / 100.0)
    return result_list_new

def calSigmoid(x, indicatorType, min_x, max_x):
    result = 0
    # min_x = floor_min(min_x)
    # max_x = floor_max(max_x)

    if min_x == max_x:
        result = 1
    else:
        b = (math.log(99) * max_x + 2 * math.log(10) * min_x) / (2 * math.log(10) + math.log(99))
        a = 2 * math.log(10) / (max_x - b)

        if indicatorType == 0:
            result = 1 - (1 / (1 + math.exp(-a * (x - b))))
        elif indicatorType == 1:
            result = (1 / (1 + math.exp(-a * (x - b))))
        elif indicatorType == 2:
            result = (1 / (1 + math.exp(-a * (x - b))))

    return result


def floor_min(min_x):
    if min_x <= 0.0001:
        return 0
    if abs(min_x) >= 1:
        output = math.floor(min_x)
    else:
        output = min_x
        count = 0
        while abs(output) < 1:
            output = output * 10
            count += 1
        output = math.floor(output)
        while count > 0:
            output = output / 10.0
            count -= 1
    return output


def floor_max(max_x):
    if max_x <= 0.0001:
        return 0
    if abs(max_x) >= 1:
        output = math.floor(max_x + 1)
    else:
        output = max_x
        count = 0
        while abs(output) < 1:
            output = output * 10
            count += 1
        output = math.floor(output + 1)
        while count > 0:
            output = output / 10.0
            count -= 1
    return output


def timeToStamp(time_in):
    timearray = time.strptime(time_in, "%Y-%m-%d %H:%M:%S")
    return time.mktime(timearray)


def stampToTime(stamp):
    strtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stamp))
    return strtime

def str_to_datetime(time_str):
    return datetime.datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")


if __name__ == "__main__":
    config = {
        "config": {
            "zgpg_start_time": "2022-02-01 00:00:00",
            "zgpg_end_time": "2022-02-14 00:00:00",
            "sat_type": 'BD3G01'
        }
    }
    print(algsMain(**config))

import datetime
import numpy as np
import re
import math
import time
from scipy.signal import argrelextrema


def algsMain(*args, **kwargs):
    '''
    计算姿态机动时段平均速度
    :param args:
    :param kwargs:
    :return:
    '''
    try:
        print("计算姿态机动时段平均速度")
        config = kwargs["config"]
        result_list = calMain(args[0], config)

        print("姿态机动时段平均速度计算完成")
        return True, result_list
    except Exception as e:
        return False, str(e.args)


def calMain(datas, config):
    rst = []
    index = config["flag"]
    count = eval(config["count"])
    order = eval(config["order"])
    door = eval(config["door"])
    diffValue = float(config["diffValue"])
    flag_value_str_list = []
    if config["flag_value"] is not '':
        flag_value_str_list = config["flag_value"].split(',')

    all_days_datas = [np.asarray(item[1:]) for item in datas]
    for idx, every_day_data in enumerate(all_days_datas):
        today_times = datas[idx][0]
        if len(today_times) == 0:
            rst.append("null")
            continue
        y_posible = []
        y_ang = []
        ang_tel_id = []
        for ang_id_index in range(1, 3):
            if config["ang_append" + str(ang_id_index)] != -1:
                ang_tel_id.append(config["ang_append" + str(ang_id_index)])
                y_ang.append(every_day_data[config["ang_append" + str(ang_id_index)]])
        for i in range(len(every_day_data)):
            if i not in ang_tel_id and i != index:
                y_posible.extend(every_day_data[i])

        if index != -1:
            y_control = np.array(every_day_data[index])
            slice_time_list = get_control_period(today_times, flag_value_str_list, y_control, count)
        else:
            y_ang.append(y_posible)
            y_ang_idx = get_y_ang_stability_idx(y_ang[0], today_times, diffValue, count)
            for y_ang_item in y_ang[1:]:
                y_ang_idx = list(np.intersect1d(y_ang_idx, get_y_ang_stability_idx(y_ang_item, today_times, diffValue, count)))
            slice_time_list = get_control_period2(y_posible, y_ang_idx)

        if len(slice_time_list) == 0:
            rst.append(0)
            continue

        delta_v_list = []
        for valid_idx_single in slice_time_list:
            final_data = []
            final_time = []
            for data_index in valid_idx_single:
                final_data.append(y_posible[data_index])
                final_time.append(today_times[data_index])
            y_posible_max_list = argrelextrema(np.array(final_data), np.greater, 0, order)
            y_posible_min_list = argrelextrema(np.array(final_data), np.less, 0, order)
            if len(y_posible_min_list[0]) == 0 and len(y_posible_max_list[0]) == 0:
                y_posible_peak_list = [0, len(final_data) - 1]
            else:
                y_posible_peak_list = list(np.union1d(y_posible_min_list, y_posible_max_list))
                y_posible_peak_list.insert(0, 0)
                y_posible_peak_list.append(len(final_data) - 1)
            for i in range(len(y_posible_peak_list) - 1):
                control_time_period = final_time[y_posible_peak_list[i + 1]] - final_time[
                    y_posible_peak_list[i]]
                delta_v = abs(final_data[y_posible_peak_list[i + 1]] - final_data[
                    y_posible_peak_list[i]]) / control_time_period
                if abs(delta_v) < door:
                    delta_v_list.append(delta_v)
        rst.append(np.nanmean(delta_v_list))
    return rst


def calGuassian(x, ideal_x, indicatorType, k, roundTFlag, min_x, max_x):
    if x == "null":
        return 1
    result = 0
    if roundTFlag == 1:
        if min_x <= x <= max_x:
            result = 1
            return result
        elif x < min_x:
            ideal_x = min_x
        elif x > max_x:
            ideal_x = max_x

    if ideal_x > 0.0001:
        min_x = floor_min(min_x)
        if k == 0:
            # k = 1.0
            k = pow((min_x - ideal_x), 2) / (pow(ideal_x, 2) * math.log(10, math.e))
        if k <= 0.0001:
            k = 1
        fx = 0
        if abs(x - ideal_x) > 0.0005:
            fx = math.exp(-pow((x - ideal_x) / (ideal_x), 2) / k)
        else:
            fx = 1

        if indicatorType == 0:
            result = 1 - fx
        elif indicatorType == 1:
            result = fx
        elif indicatorType == 2:
            result = fx
    else:
        result = 1

    return result


def calSigmoid(x, indicatorType, min_x, max_x):
    result = 0
    # min_x = floor_min(min_x)
    # max_x = floor_max(max_x)

    if min_x == max_x:
        result = 1
    else:
        b = (math.log(99) * max_x + 2 * math.log(10) * min_x) / (2 * math.log(10) + math.log(99))
        a = 2 * math.log(10) / (max_x - b)

        if indicatorType == 0:
            result = 1 - (1 / (1 + math.exp(-a * (x - b))))
        elif indicatorType == 1:
            result = (1 / (1 + math.exp(-a * (x - b))))
        elif indicatorType == 2:
            result = (1 / (1 + math.exp(-a * (x - b))))

    return result


def floor_min(min_x):
    if min_x <= 0.0001:
        return 0
    if abs(min_x) >= 1:
        output = math.floor(min_x)
    else:
        output = min_x
        count = 0
        while abs(output) < 1:
            output = output * 10
            count += 1
        output = math.floor(output)
        while count > 0:
            output = output / 10.0
            count -= 1
    return output


def floor_max(max_x):
    if max_x <= 0.0001:
        return 0
    if abs(max_x) >= 1:
        output = math.floor(max_x + 1)
    else:
        output = max_x
        count = 0
        while abs(output) < 1:
            output = output * 10
            count += 1
        output = math.floor(output + 1)
        while count > 0:
            output = output / 10.0
            count -= 1
    return output


def timeToStamp(time_in):
    timearray = time.strptime(time_in, "%Y-%m-%d %H:%M:%S")
    return time.mktime(timearray)


def stampToTime(stamp):
    strtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stamp))
    return strtime


def str_to_datetime(time_str):
    return datetime.datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")


def get_control_period(today_times, flag_value_str_list, y_control, count):
    valid_idx = []
    for flag_value_str in flag_value_str_list:
        flag_value = eval(flag_value_str)
        y_control_idx = np.where(abs(np.array(y_control) - flag_value) <= 0.01)
        y_control_idx = y_control_idx[0]
        if len(y_control_idx) == 0:
            break

        idxs = np.array([(i in y_control_idx) for i in range(len(today_times))])
        idxs = np.where(idxs == True, 1, 0)

        # 稳态时段
        # 把 1 置为 1，0置为0
        norm = idxs
        # 找连续5次触发1的置为c，其他不替换
        norm_continous = re.sub(r'1{' + str(count) + ',}', lambda x: 'c' * len(x.group()), ''.join(map(str, norm)))
        # 找出连续为c的索引
        norm_continous_idx = np.array(list(norm_continous)) == 'c'
        norm_continous_idx = np.where(norm_continous_idx == True)
        if len(norm_continous_idx[0]) != 0:
            # 找出索引差分>1的索引，即每一段连续的开始的索引
            diffidxofidx = np.where((np.diff(norm_continous_idx) > 1)[0])
            diffidxofidx = diffidxofidx[0]

            list_norm_continous_idx = list(norm_continous_idx)[0]

            for i in range(-1, len(diffidxofidx)):
                if len(diffidxofidx) == 0:
                    valid_idx.append(list_norm_continous_idx[:])
                else:
                    if i == -1:
                        valid_idx.append(list_norm_continous_idx[:diffidxofidx[i + 1] + 1])
                    elif i == len(diffidxofidx) - 1:
                        valid_idx.append(list_norm_continous_idx[diffidxofidx[i] + 1:])
                    else:
                        valid_idx.append(list_norm_continous_idx[diffidxofidx[i] + 1:diffidxofidx[i + 1] + 1])
    return valid_idx


def get_control_period2(y_posible, y_ang_idx):
    time_slice_list_index = []
    time_slice_index = []
    pre = False

    if len(y_ang_idx) == 0:
        time_slice_index = [0, len(y_posible) - 1]
        time_slice_list_index.append(list(range(time_slice_index[0], time_slice_index[-1] + 1)))
        return time_slice_list_index
    for index in range(len(y_posible)):
        if len(time_slice_index) == 2:
            time_slice_list_index.append(list(range(time_slice_index[0], time_slice_index[-1] + 1)))
            time_slice_index.clear()
        if index not in y_ang_idx and pre is False:
            if len(time_slice_index) == 1:
                time_slice_index.clear()
            time_slice_index.append(index)
            pre = True
        if index in y_ang_idx and pre is True:
            time_slice_index.append(index - 1)
            if time_slice_index[0] == time_slice_index[-1]:
                time_slice_index.clear()
            pre = False

    return time_slice_list_index


def get_y_ang_stability_idx(y_ang, today_times, diffValue, count):
    y_ang_idx = list(np.where(abs(np.diff(y_ang)) < diffValue)[0])
    delete_idx = set([])
    y_time_idx = np.where(np.diff(today_times) <= 10)
    splitTime_continous_idx = split_continous_idx(y_time_idx[0], today_times, count)
    for splitTime_continous_idx_single in splitTime_continous_idx:
        splitTime_continous_idx_single = list(np.intersect1d(y_ang_idx, splitTime_continous_idx_single))
        # for delete_count in range(2, 10):
        #     for index_ang, item_ang in enumerate(splitTime_continous_idx_single[delete_count:]):
        #         if abs(y_ang[item_ang] - y_ang[splitTime_continous_idx_single[index_ang - delete_count]]) >= 0.1 and item_ang in y_ang_idx:
        #             y_ang_idx.remove(item_ang)
        for index_ang, item_ang in enumerate(splitTime_continous_idx_single):
            if index_ang >= 5 and abs(y_ang[item_ang] - y_ang[
                splitTime_continous_idx_single[index_ang - 5]]) >= diffValue and item_ang in y_ang_idx:
                for delete_item in splitTime_continous_idx_single[index_ang - 5: index_ang + 1]:
                    delete_idx.add(delete_item)
            if index_ang >= 10 and abs(y_ang[item_ang] - y_ang[
                splitTime_continous_idx_single[index_ang - 10]]) >= diffValue and item_ang in y_ang_idx:
                for delete_item in splitTime_continous_idx_single[index_ang - 10: index_ang + 1]:
                    delete_idx.add(delete_item)
            if index_ang >= 20 and abs(y_ang[item_ang] - y_ang[
                splitTime_continous_idx_single[index_ang - 20]]) >= diffValue and item_ang in y_ang_idx:
                for delete_item in splitTime_continous_idx_single[index_ang - 20: index_ang + 1]:
                    delete_idx.add(delete_item)
            if index_ang >= 30 and abs(y_ang[item_ang] - y_ang[
                splitTime_continous_idx_single[index_ang - 30]]) >= diffValue and item_ang in y_ang_idx:
                for delete_item in splitTime_continous_idx_single[index_ang - 30: index_ang + 1]:
                    delete_idx.add(delete_item)
    for delete_item_idx in delete_idx:
        y_ang_idx.remove(delete_item_idx)

    return y_ang_idx


def split_continous_idx(tmp_idx, today_times, count):
    idxs = np.array([(i in tmp_idx) for i in range(len(today_times))])
    idxs = np.where(idxs == True, 1, 0)

    # 稳态时段
    # 把 1 置为 1，0置为0
    norm = idxs
    # 找连续5次触发1的置为c，其他不替换
    norm_continous = re.sub(r'1{' + str(count) + ',}', lambda x: 'c' * len(x.group()), ''.join(map(str, norm)))
    # 找出连续为c的索引
    norm_continous_idx = np.array(list(norm_continous)) == 'c'
    norm_continous_idx = np.where(norm_continous_idx == True)
    valid_idx = []
    if len(norm_continous_idx[0]) != 0:
        # 找出索引差分>1的索引，即每一段连续的开始的索引
        diffidxofidx = np.where((np.diff(norm_continous_idx) > 1)[0])
        diffidxofidx = diffidxofidx[0]
        list_norm_continous_idx = list(norm_continous_idx)[0]
        for i in range(-1, len(diffidxofidx)):
            if len(diffidxofidx) == 0:
                valid_idx.append(list_norm_continous_idx[:])
            else:
                if i == -1:
                    valid_idx.append(list_norm_continous_idx[:diffidxofidx[i + 1] + 1])
                elif i == len(diffidxofidx) - 1:
                    valid_idx.append(list_norm_continous_idx[diffidxofidx[i] + 1:])
                else:
                    valid_idx.append(list_norm_continous_idx[diffidxofidx[i] + 1:diffidxofidx[i + 1] + 1])
    return valid_idx


def log(logStr):
    with open("D:/log.log", "a", encoding="UTF-8") as f:
        # f.write(str(datetime.datetime.now()) + " [INFO]:    " + str(logStr))
        f.write(str(logStr))
        f.write("\n")


if __name__ == "__main__":
    print(stampToTime(1672505924))
    config = {
        "config": {
            "zgpg_start_time": "2019-04-01 00:00:00",
            "zgpg_end_time": "2019-04-10 23:59:59",
            "sat_type": "BD3G01"
        }
    }
    print(algsMain(**config))

import pandas as pd
import numpy as np
import requests
import json, time, math


def algsMain(*args, **kwargs):
    '''
    sigmoid效用函数
    :param args:
    :param kwargs:
    :return:
    '''
    # try:
    print('sigmoid效用函数开始量化')
    rst = args[0]
    config = kwargs["config"]
    indicator_type = int(config["indicatorType"])
    rst_base = config["base_data"]

    replaceList(rst, 'null', None)
    replaceList(rst_base, 'null', None)

    rst_base_data = []
    for rst_base_item in rst_base:
        if rst_base_item is not None:
            rst_base_data.append(rst_base_item)

    if len(rst_base_data) == 0:
        min_value = None
        max_value = None
    else:
        min_value = np.min(rst_base_data)
        max_value = np.max(rst_base_data)
    if "min" in config.keys():
        min_value = config["min"]
    if "max" in config.keys():
        max_value = config["max"]
    mapRange = 'sigmoid效用函数使用的区间为' + '[' + str(min_value) + ', ' + str(max_value) + ']'

    fx_list = []
    for item in rst:
        fx_list.append(calSigmoid(item, indicator_type, min_value, max_value))

    rst.extend(fx_list)
    return_data = {
        "mapRange": mapRange,
        "value": rst
    }
    print("sigmoid效用函数已计算完成")
    return True, return_data


def replaceList(inputList, pre, current):
    for index, item in enumerate(inputList):
        if item == pre:
            inputList[index] = current


def calSigmoid(x, indicatorType, min_x, max_x):
    result = 0
    # min_x = floor_min(min_x)
    # max_x = floor_max(max_x)
    if x is None:
        result = 1
    if min_x == max_x or min_x is None:
        result = 1
    else:
        b = (math.log(99) * max_x + 2 * math.log(10) * min_x) / (2 * math.log(10) + math.log(99))
        a = 2 * math.log(10) / (max_x - b)

        if indicatorType == 0:
            result = 1 - (1 / (1 + math.exp(-a * (x - b))))
        elif indicatorType == 1:
            result = (1 / (1 + math.exp(-a * (x - b))))
        elif indicatorType == 2:
            result = (1 / (1 + math.exp(-a * (x - b))))

    return result


def floor_min(min_x):
    if min_x <= 0.0001:
        return 0
    if abs(min_x) >= 1:
        output = math.floor(min_x)
    else:
        output = min_x
        count = 0
        while abs(output) < 1:
            output = output * 10
            count += 1
        output = math.floor(output)
        while count > 0:
            output = output / 10.0
            count -= 1
    return output


def floor_max(max_x):
    if max_x <= 0.0001:
        return 0
    if abs(max_x) >= 1:
        output = math.floor(max_x + 1)
    else:
        output = max_x
        count = 0
        while abs(output) < 1:
            output = output * 10
            count += 1
        output = math.floor(output + 1)
        while count > 0:
            output = output / 10.0
            count -= 1
    return output

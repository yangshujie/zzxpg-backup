package com.ruoyi.common.core.stkcomp.entity;

import agi.foundation.time.Duration;
import com.alibaba.fastjson.JSONArray;


import java.awt.*;
import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Properties;
import java.util.Random;

/**
 * @ClassName MyUtil
 * @Description TODO
 * @date 2022/7/15 16:50
 * @Version 1.0
 */

public class MyUtil {

    public static Color randomColor(int alpha) {
        Random rnd = new Random();
        alpha = Math.min(Math.max(0, alpha), 255);
        return new Color(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256),alpha);
    }

    public static ByteArrayOutputStream readCzmlFile(String filepath) {
        File file = new File(filepath);
        if (!file.exists()) {
            return null;
        }
        try (
                FileInputStream fis = new FileInputStream(filepath);
                FileChannel fisChannel = fis.getChannel();
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream((int) fisChannel.size())
        ) {
            //分配缓冲区，设定每次读的字节数
            ByteBuffer byteBuffer = ByteBuffer.allocate(4);

            //读取数据
            int len = 0;
            while ((len = fisChannel.read(byteBuffer)) > 0) {
                //上面把数据写入到了buffer，所以可知上面的buffer是写模式，调用flip把buffer切换到读模式，读取数据
                byteBuffer.flip();
                byteArrayOutputStream.write(byteBuffer.array(), 0, len);
                byteBuffer.clear();
            }
            return byteArrayOutputStream;
        } catch (Exception e) {
            return null;
        }
    }
    public static JSONArray ConvertToJsonArray(String path){

        JSONArray jsonArray =null;
        BufferedReader reader = null;
        StringBuilder jsonStrs = new StringBuilder();
        InputStream inputStream=null;
        try {
            inputStream = Files.newInputStream(Paths.get(path));
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
            reader = new BufferedReader(inputStreamReader);
            String tempStr;
            while ((tempStr = reader.readLine()) != null) {
                jsonStrs.append(tempStr);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        try{
            jsonArray=JSONArray.parseArray(jsonStrs.toString().trim());
        }catch(Exception e){
            e.printStackTrace();
        }
        return jsonArray;
    }

    public static InputStream getFile(String filePath){
        InputStream inputStream = null;
        File src=new File(filePath);
        try {
            inputStream = Files.newInputStream(src.toPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return inputStream;
    }


    /**
     * 获取当前服务的ip和端口
     * @return string
     */
    public static String getUrl() {
        InetAddress address = null;

        try {
            address = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        assert address != null;
        return "http://" +address.getHostAddress() +":"+ 8083;
    }

    public static String getModelUrl(){
        return getUrl() + "/models/";
    }
    public static Duration toDuration (String num,String unit){
        Duration duration = Duration.fromHours(1.0);
        if (unit!=null)
            switch (unit) {
                case "d": duration = Duration.fromDays(Double.parseDouble(num));break;
                case "h": duration = Duration.fromHours(Double.parseDouble(num));break;
                case "m": duration = Duration.fromMinutes(Double.parseDouble(num));break;
                case "s": duration = Duration.fromSeconds(Double.parseDouble(num));break;
            }
        return duration;
    }
    public static Duration toDuration (String durationString){
        String[] temp = durationString.split(":");
        return new Duration(Integer.parseInt(temp[0]),Double.parseDouble(temp[1]));
    }
    public static HashMap<String,String> toDurationStrings(Duration duration){
        HashMap<String,String> map = new HashMap<>();
        if (duration.getTotalSeconds()<=60){
            map.put("unit","s");
            map.put("num", String.valueOf(duration.getTotalSeconds()));
        } else if (duration.getTotalSeconds()<=3600) {
            map.put("unit","m");
            map.put("num", String.valueOf(duration.getTotalSeconds()/60));
        }else if (duration.getTotalSeconds()<=86400) {
            map.put("unit","m");
            map.put("num", String.valueOf(duration.getTotalSeconds()/86400));
        }else {
            map.put("unit","d");
            map.put("num", String.valueOf(duration.getTotalDays()));
        }
        return map;
    }




}

package com.ruoyi.common.core.stkcomp;
import agi.foundation.Bounds;
import agi.foundation.Trig;
import agi.foundation.TypeLiteral;
import agi.foundation.access.AccessQuery;
import agi.foundation.access.AccessQueryAnd;
import agi.foundation.access.LinkInstantaneous;
import agi.foundation.access.LinkRole;
import agi.foundation.access.constraints.CentralBodyObstructionConstraint;
import agi.foundation.access.constraints.CentralBodySurfaceRegionElevationAngleConstraint;
import agi.foundation.celestial.CentralBodiesFacet;
import agi.foundation.celestial.EarthCentralBody;
import agi.foundation.cesium.LinkGraphicsExtension;
import agi.foundation.cesium.ModelGraphics;
import agi.foundation.cesium.ModelGraphicsExtension;
import agi.foundation.cesium.*;
import agi.foundation.coordinates.Cartesian;
import agi.foundation.coordinates.Cartographic;
import agi.foundation.coordinates.UnitCartesian;
import agi.foundation.coverage.AssetDefinition;
import agi.foundation.coverage.CoverageGridPointWithResults;
import agi.foundation.coverage.CoverageResults;
import agi.foundation.coverage.ParameterizedTemporallyPartitionedCoverageDefinition;
import agi.foundation.coverage.figureofmerit.NumberOfAssets;
import agi.foundation.coverage.figureofmerit.RevisitTime;
import agi.foundation.geometry.*;
import agi.foundation.geometry.discrete.SurfaceRegionsCoverageGrid;
import agi.foundation.geometry.shapes.EllipsoidSurfaceRegion;
import agi.foundation.geometry.shapes.RectangularPyramid;
import agi.foundation.infrastructure.IdentifierExtension;
import agi.foundation.platforms.*;
import agi.foundation.time.Duration;
import agi.foundation.time.JulianDate;
import agi.foundation.time.TimeInterval;
import agi.foundation.time.TimeIntervalCollection;
import lombok.Data;

import java.io.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import static agi.foundation.access.LinkRole.RECEIVER;
import static agi.foundation.access.LinkRole.TRANSMITTER;
import static agi.foundation.cesium.advanced.CesiumProperty.toCesiumProperty;
import static fzyk.stkcomp.entity.MyUtil.randomColor;
import static java.awt.Color.WHITE;
import static java.awt.Color.YELLOW;

@Data
public class StkSceneUtil implements Serializable{
    String sceneName = "sceneName";
    JulianDate start_epoch;
    JulianDate end_epoch;
    JulianDate currectTime;
    Double multiplier = 1.0;
    private final EarthCentralBody m_earth = CentralBodiesFacet.getFromContext().getEarth();
    public TimeInterval dataInterval;
    String sceneDescription = "";

    //    List<Platform> platformList = new ArrayList<>();
    //看后面有没有需要做查找 如果需要显示分别显示可能需要分开存一下各个platform数据
    private PlatformCollection platforms = new PlatformCollection();
    //    private PlatformCollection sensorList = new PlatformCollection();
    //    private PlatformCollection areaTargetList = new PlatformCollection();
    CzmlDocument czmlDocument = new CzmlDocument();

    /**
     * 新建场景  默认时间
     */
    public StkSceneUtil() {
        //前四行是测试对比日期时使用，后面使用当前时间需要隐掉前四行
        LocalDateTime ldt = LocalDateTime.of(2021, 9, 21, 13, 0, 0);
//        LocalDateTime ldt = LocalDateTime.now();
        ZonedDateTime zbj = ldt.atZone(ZoneId.of("Asia/Shanghai"));
        start_epoch = new JulianDate(zbj);
        end_epoch = start_epoch.addDays(1);
        dataInterval = new TimeInterval(start_epoch, end_epoch);
    }

    /**
     * 新建场景
     * @param start_epoch 场景开始时间
     * @param end_epoch 场景结束时间
     */
    public StkSceneUtil(JulianDate start_epoch, JulianDate end_epoch){
        this.start_epoch = start_epoch;
        this.end_epoch = end_epoch;
        dataInterval = new TimeInterval(this.start_epoch, this.end_epoch);
    }

    /**
     * 场景导出czml字节流
     * @return
     * @throws IOException
     */
    public ByteArrayOutputStream getCzml() throws IOException {
        // Create and configure the CZML document.d
        czmlDocument.setName(sceneName);
        czmlDocument.setDescription(sceneDescription);
        czmlDocument.setRequestedInterval(dataInterval);

        czmlDocument.setStep(Duration.fromMinutes(1));

        // For this demonstration, include whitespace in the CZML
        // to enable easy inspection of the contents. In a real application,
        // this would usually be false to reduce file size.
        //czml文件是否有空格
        czmlDocument.setPrettyFormatting(true);

        // Configure the clock on the client to reflect the time for which the data is computed.
        Clock clock = new Clock();
        clock.setInterval(dataInterval);
        if(currectTime!=null){
            clock.setCurrentTime(currectTime);
        }else {
            clock.setCurrentTime(dataInterval.getStart());
        }
        clock.setMultiplier(multiplier);
        czmlDocument.setClock(clock);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
//        OutputStream out = System.out;//打印到控制台
        //OutputStream out = new FileOutputStream("D:\\demo.txt");//打印到文件
        OutputStreamWriter osr = new OutputStreamWriter(out);//输出
        czmlDocument.writeDocument(osr);
        osr.close();
        return out;
    }
    public void saveCzml(String czmlPath) throws IOException {
        // Create and configure the CZML document.d
        czmlDocument.setName(sceneName);
        czmlDocument.setDescription(sceneDescription);
        czmlDocument.setRequestedInterval(dataInterval);
        czmlDocument.setStep(Duration.fromMinutes(1));
        // For this demonstration, include whitespace in the CZML
        // to enable easy inspection of the contents. In a real application,
        // this would usually be false to reduce file size.
        //czml文件是否有空格
        czmlDocument.setPrettyFormatting(true);
        // Configure the clock on the client to reflect the time for which the data is computed.
        Clock clock = new Clock();
        clock.setInterval(dataInterval);
        if(currectTime!=null){
            clock.setCurrentTime(currectTime);
        }else {
            clock.setCurrentTime(dataInterval.getStart());
        }
        clock.setMultiplier(multiplier);
        czmlDocument.setClock(clock);


//        ByteArrayOutputStream out = new ByteArrayOutputStream();
//        OutputStream out = System.out;//打印到控制台
        OutputStream out = new FileOutputStream(czmlPath);//打印到文件
        OutputStreamWriter osr = new OutputStreamWriter(out);//输出
        czmlDocument.writeDocument(osr);
        osr.close();
        out.close();
        return;
    }
    /**
     * 在场景中加入一个platform
     * @param platform
     */
    public void addPlatForm(Platform platform){
        platforms.add(platform);
        czmlDocument.getObjectsToWrite().add(platform);
//        for(Platform child : platform.getChildren()){
//            addPlatForm(child);
//        }
    }
    /**
     * 在场景中加入多个platform
     * @param platformCollection
     */
    public void addPlatFormCollection (PlatformCollection platformCollection){
        for (Platform platform : platformCollection){
            addPlatForm(platform);
        }
    }

    /**
     * 在场景中加入一个platform
     * @param link
     */
    public void addPlatForm(LinkInstantaneous link){
        czmlDocument.getObjectsToWrite().add(link);
    }
    /*-------上面是整理过的内容------------*/


    /**
     * 未整理...后面还需要改
     * @param location
     * @return
     */
    public Platform addFacility(Cartographic location) {
        // Define the location of the facility using cartographic coordinates.
//        Cartographic location = new Cartographic(Trig.degreesToRadians(-75.596766667), Trig.degreesToRadians(40.0388333333), 0.0);
        Point locationPoint = new PointCartographic(m_earth, location);
        Platform new_facility = new Platform();
        new_facility.setName("AGI HQ");
        new_facility.setLocationPoint(locationPoint);
//        platformList.add(new_facility);
        // Orient the facility using East-North-Up (ENU) axes.
        new_facility.setOrientationAxes(new AxesEastNorthUp(m_earth, locationPoint));

        // Set the identifier for the facility in the CZML document.
        new_facility.getExtensions().add(new IdentifierExtension("AGI"));

        // Configure a glTF model for the facility.
        ModelGraphics modelGraphics = new ModelGraphics();

        // Link to a binary glTF file.
//        modelGraphics.setModel(toCesiumProperty(new CesiumResource(getModelUri("facility.glb"), CesiumResourceBehavior.LINK_TO)));
        modelGraphics.setRunAnimations(toCesiumProperty(false));
        modelGraphics.setHeightReference(toCesiumProperty(CesiumHeightReference.CLAMP_TO_GROUND));

        new_facility.getExtensions().add(new ModelGraphicsExtension(modelGraphics));

        // Configure label for AGI HQ.
        LabelGraphics labelGraphics = new LabelGraphics();
        labelGraphics.setText(toCesiumProperty(new_facility.getName()));
        labelGraphics.setFillColor(toCesiumProperty(WHITE));

        // Only show label when camera is far enough from the satellite,
        // to avoid visually clashing with the model.
        labelGraphics.setDistanceDisplayCondition(toCesiumProperty(new Bounds(1000.0, Double.MAX_VALUE)));

        new_facility.getExtensions().add(new LabelGraphicsExtension(labelGraphics));
        czmlDocument.getObjectsToWrite().add(new_facility);
        return new_facility;
    }

    /**
     * 未整理...后面还需要改
     * @param m_sensor
     * @param centralBodySurfaceRegion
     * @return
     */
    public LinkInstantaneous addSensorCentralBodySurfaceRegionLink(Platform m_sensor ,Platform centralBodySurfaceRegion){
        LinkInstantaneous m_satelliteFacilityLink = new LinkInstantaneous(m_sensor,centralBodySurfaceRegion);
        // Set the identifier for the link in the CZML document.
        m_satelliteFacilityLink.getExtensions().add(new IdentifierExtension("Sensor_"+m_sensor.getName()+"/"+"CentralBodySurfaceRegion_"+centralBodySurfaceRegion.getName()));
        // Specify how access should be constrained.  In this case,
        // access will only exist when no part of the earth is between AGI HQ and the satellite.
        CentralBodySurfaceRegionElevationAngleConstraint m_accessQuery = new CentralBodySurfaceRegionElevationAngleConstraint(m_satelliteFacilityLink, RECEIVER,3.14/4);
        AxesTargetingLink axesTargetingLink = new AxesTargetingLink(m_accessQuery.getConstrainedLink(), LinkRole.TRANSMITTER,new VectorFixed(m_sensor.getParent().getOrientationAxes(), Cartesian.toCartesian(UnitCartesian.getUnitZ())));

        m_sensor.setOrientationAxes(axesTargetingLink);

        TypeLiteral<FieldOfViewGraphicsExtension> typeLiteral = new TypeLiteral<FieldOfViewGraphicsExtension>(){};
        SensorFieldOfViewGraphics fieldOfViewGraphics = m_sensor.getExtensions().getByType(typeLiteral).getFieldOfViewGraphics();
        fieldOfViewGraphics.setShow(new AccessQueryCesiumProperty<>(m_accessQuery, true, false, false));

        // Configure graphical display of the access link.
        LinkGraphics linkGraphics = new LinkGraphics();
        // Show the access link only when access is satisfied.
        linkGraphics.setShow(new AccessQueryCesiumProperty<>(m_accessQuery, true, false, false));
        linkGraphics.setMaterial(toCesiumProperty(new SolidColorMaterialGraphics(YELLOW)));
        m_satelliteFacilityLink.getExtensions().add(new LinkGraphicsExtension(linkGraphics));
        TypeLiteral<AccessConstraintsExtension> typeLiteral2 = new TypeLiteral<AccessConstraintsExtension>(){};
        m_sensor.getExtensions().getByType(typeLiteral2).getConstraints().add(m_accessQuery);
//        System.out.println(m_sensor.getExtensions().getByType(typeLiteral2).getConstraints().size());
        czmlDocument.getObjectsToWrite().add(m_satelliteFacilityLink);
        return m_satelliteFacilityLink;
    }

    /**
     * 未整理...后面还需要改
     * @param m_facility
     * @param m_satellite
     * @param m_satelliteFacilityLink
     */
    public void createFacilitySensor( Platform m_facility,Platform m_satellite, LinkInstantaneous m_satelliteFacilityLink) {
        Platform m_facilitySensor = new Platform();
        // Use the same location point as the facility.
        m_facilitySensor.setLocationPoint(m_facility.getLocationPoint());
        // Orient the sensor to target the link with the satellite.
        m_facilitySensor.setOrientationAxes(new AxesTargetingLink(m_satelliteFacilityLink, TRANSMITTER,
                new VectorFixed(m_satellite.getOrientationAxes(), Cartesian.toCartesian(UnitCartesian.getUnitZ()))));

        // Set the identifier for the facility in the CZML document.
        m_facilitySensor.getExtensions().add(new IdentifierExtension("Sensor2"));

        // Define the sensor geometry.
        RectangularPyramid fieldOfView = new RectangularPyramid();
        fieldOfView.setXHalfAngle(Trig.degreesToRadians(8.0));
        fieldOfView.setYHalfAngle(Trig.degreesToRadians(4.5));
        fieldOfView.setRadius(500000.0);

        m_facilitySensor.getExtensions().add(new FieldOfViewExtension(fieldOfView));

        // Configure graphical display of the sensor.
        SensorFieldOfViewGraphics sensorFieldOfViewGraphics = new SensorFieldOfViewGraphics();

        // Show the sensor only when access is satisfied.
        AccessQuery m_accessQuery = new CentralBodyObstructionConstraint(m_satelliteFacilityLink, m_earth);
//        sensorFieldOfViewGraphics.setShow(new AccessQueryCesiumProperty<>(m_accessQuery, true, false, false));
        sensorFieldOfViewGraphics.setShow(toCesiumProperty(true));
        GridMaterialGraphics domeSurfaceMaterial = new GridMaterialGraphics();
        domeSurfaceMaterial.setColor(toCesiumProperty(WHITE));
        domeSurfaceMaterial.setCellAlpha(toCesiumProperty(0.0));
        sensorFieldOfViewGraphics.setDomeSurfaceMaterial(toCesiumProperty(domeSurfaceMaterial));

        SolidColorMaterialGraphics lateralSurfaceMaterial = new SolidColorMaterialGraphics(randomColor(123));
        sensorFieldOfViewGraphics.setLateralSurfaceMaterial(toCesiumProperty(lateralSurfaceMaterial));

        m_facilitySensor.getExtensions().add(new FieldOfViewGraphicsExtension(sensorFieldOfViewGraphics));

        czmlDocument.getObjectsToWrite().add(m_facilitySensor);
    }
    /**
     * 新建覆盖区域计算
     * @param assetsPlatformList 扫描对象
     * @param areaTargetPlatformList 扫描区域
     * @return
     */
    public List<Double> createCoverageDefinition(List<Platform> assetsPlatformList,  List<Platform> areaTargetPlatformList){
        List<Double> list = new ArrayList<>();
        List<EllipsoidSurfaceRegion> areaTargetSurfaceRegionList = new ArrayList<>();
        for (int i=0;i<areaTargetPlatformList.size();i++){
            TypeLiteral<CentralBodySurfaceRegion> typeLiteral = new TypeLiteral<CentralBodySurfaceRegion>(){};
//            System.out.println(areaTargetPlatformList.get(i));
            EllipsoidSurfaceRegion areaTargetSurfaceRegion= areaTargetPlatformList.get(i).getExtensions().getByType(typeLiteral).getSurfaceRegion();
            areaTargetSurfaceRegionList.add(areaTargetSurfaceRegion);
        }
        SurfaceRegionsCoverageGrid surfaceRegionsCoverageGrid = new SurfaceRegionsCoverageGrid(Trig.degreesToRadians(1), m_earth, areaTargetSurfaceRegionList);
        ParameterizedTemporallyPartitionedCoverageDefinition coverage = new ParameterizedTemporallyPartitionedCoverageDefinition(surfaceRegionsCoverageGrid,true);

        for (Platform platform : assetsPlatformList) {
            // Create a new link between your satellite and the grid by using the placeholder
            // satellite is the transmitter, grid is the receiver
            LinkInstantaneous newLink = new LinkInstantaneous(platform, coverage.getGridPointPlaceholder());

            // Apply a sensor volume constraint to the grid (receiver)
            CentralBodyObstructionConstraint centralBodyObstructionConstraint = new CentralBodyObstructionConstraint(newLink,m_earth);

            TypeLiteral<AccessConstraintsExtension> typeLiteral = new TypeLiteral<AccessConstraintsExtension>(){};
            AccessQuery accessQuery = centralBodyObstructionConstraint;
            boolean isRequired = false;
            if(platform.getExtensions().getByType(typeLiteral)!=null) {
                for (AccessQuery accessQuery2 : platform.getExtensions().getByType(typeLiteral).getConstraints()) {
                    accessQuery = new AccessQueryAnd(accessQuery, accessQuery2);
                }
            }
            coverage.addAsset(new AssetDefinition(platform, accessQuery, isRequired));
//            coverage.addAsset(new AssetDefinition(platform, centralBodyObstructionConstraint, isRequired));

        }
        CoverageResults coverageResults = coverage.computeCoverageOverTheGrid(new TimeIntervalCollection(dataInterval),Duration.fromMinutes(5));
//            System.out.println(coverageResults.getGridPoints().size());
        double num = 0.0;
        double max = 0;
        double min = 0;
        for (CoverageGridPointWithResults coverageGridPointWithResults :coverageResults.getGridPoints()){
//                System.out.println(coverageGridPointWithResults.getAssetCoverage().getSatisfactionIntervalsWithNumberOfAssets().size());
//                for(TimeInterval1<Integer> timeIntervalCollection1 :coverageGridPointWithResults.getAssetCoverage().getSatisfactionIntervalsWithNumberOfAssets()){
//                    System.out.println(timeIntervalCollection1.getStart());
//                    System.out.println(timeIntervalCollection1.getStop());
//                    System.out.println(timeIntervalCollection1.getData());
//                }

            num = num + NumberOfAssets.averageNumberOfAssets(coverageGridPointWithResults.getAssetCoverage());
            max = max + NumberOfAssets.maximumNumberOfAssets(coverageGridPointWithResults.getAssetCoverage());
            min = min + NumberOfAssets.minimumNumberOfAssets(coverageGridPointWithResults.getAssetCoverage());
//            System.out.println(RevisitTime.averageRevisitTime(coverageGridPointWithResults.getAssetCoverage()));
//            System.out.println(RevisitTime.maximumRevisitTime(coverageGridPointWithResults.getAssetCoverage()));
//            System.out.println(RevisitTime.minimumRevisitTime(coverageGridPointWithResults.getAssetCoverage()));
            list.add(RevisitTime.minimumRevisitTime(coverageGridPointWithResults.getAssetCoverage()));
        }
        num = num/coverageResults.getGridPoints().size()*100;
        max = max/coverageResults.getGridPoints().size()*100;
        min = min/coverageResults.getGridPoints().size()*100;
//        System.out.println(num);
//        System.out.println(max);
//        System.out.println(min);
    return list;
    }

}

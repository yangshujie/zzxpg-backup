package com.ruoyi.common.core.stkcomp;

/**
 * @ClassName SceneException
 * @Description TODO
 * @author: ltq
 * @date 2022/8/24 12:40
 * @Version 1.0
 */
public class SceneException extends RuntimeException{
    public SceneException() {
        super();
    }
    public SceneException(String str) {
        super(str);
    }
}

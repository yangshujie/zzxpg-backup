package com.ruoyi.common.core.stkcomp.entity;

import agi.foundation.DateMotionCollection2;
import agi.foundation.Trig;
import agi.foundation.TypeLiteral;
import agi.foundation.access.*;
import agi.foundation.access.constraints.CentralBodySurfaceRegionConstraint;
import agi.foundation.access.constraints.CentralBodySurfaceRegionElevationAngleConstraint;
import agi.foundation.celestial.CentralBodiesFacet;
import agi.foundation.celestial.EarthCentralBody;
import agi.foundation.cesium.*;
import agi.foundation.coordinates.Cartesian;
import agi.foundation.coordinates.Cartographic;
import agi.foundation.coordinates.UnitCartesian;
import agi.foundation.coordinates.UnitQuaternion;
import agi.foundation.geometry.*;
import agi.foundation.geometry.shapes.*;
import agi.foundation.infrastructure.IdentifierExtension;
import agi.foundation.platforms.*;
import agi.foundation.time.*;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static agi.foundation.Constants.TwoPi;
import static agi.foundation.access.LinkRole.RECEIVER;
import static agi.foundation.cesium.advanced.CesiumProperty.toCesiumProperty;
import static java.awt.Color.WHITE;


/**
 * @ClassName Sensor
 * @Description TODO
 * @date 2022/7/15 10:45
 * @Version 1.0
 */
public class Sensor2 extends Platform {
    static EarthCentralBody m_earth = CentralBodiesFacet.getFromContext().getEarth();
    private Color color;
    private TimeInterval availableTime;
    private FieldOfViewExtension fieldOfViewExtension;

    /**
     * 新建Sensor  默认Rectangular类型[4.0, 8.5]
     * @param m_satellite sensor关联卫星
     * @param sensorName sensor名称
     */
    public Sensor2(Satellite m_satellite, String sensorName){
        this(m_satellite,sensorName,SensorType.Rectangular, new Double[]{4.0, 8.5});
    }

    /**
     * 新建Sensor
     * @param m_satellite sensor关联卫星
     * @param sensorName  sensor名称
     * @param type        类型
     * @param halfAnglePara 输入传感器相关数据  Rectangular 类型需要输入xyHalfAngle两个角度值  SimpleConic 类型需要输入一个halfAngle角度值   ComplexConic 需要innerHalfAngle，outerHalfAngle，minClockAngle，maxClockAngle四个
     */
    public Sensor2(Satellite m_satellite, String sensorName, SensorType type, Double halfAnglePara[]){
        super();
        setLocationPoint(m_satellite.getLocationPoint());
        availableTime = m_satellite.getAvailableTime();
        // Orient the sensor to target the link with the satellite.
        //sensor指向目标卫星方向
//        m_satlliteSensor.setOrientationAxes(new AxesTargetingLink(m_satelliteFacilityLink, LinkRole.TRANSMITTER,
//                new VectorFixed(m_facility.getOrientationAxes(), Cartesian.toCartesian(UnitCartesian.getUnitZ()))));
        setParent(m_satellite);
        setOrientationAxes(new AxesNorthEastDown(m_earth,m_satellite.getLocationPoint()));
//        System.out.println(sensor);
//        m_satlliteSensor.getExtensions().add(new IdentifierExtension("Sensor_"+sensor.getString("sensorName")));
        setName(sensorName);
        setSensorProp(type,halfAnglePara);
        // Configure graphical display of the sensor.
        SensorFieldOfViewGraphics sensorFieldOfViewGraphics = new SensorFieldOfViewGraphics();
//        AccessQuery m_accessQuery = new CentralBodyObstructionConstraint(m_satelliteFacilityLink, m_earth);
//        // Show the sensor only when access is satisfied.
//        sensorFieldOfViewGraphics.setShow(new AccessQueryCesiumProperty<>(m_accessQuery, true, false, false));
        sensorFieldOfViewGraphics.setShow(toCesiumProperty(true));
        GridMaterialGraphics domeSurfaceMaterial = new GridMaterialGraphics();
        domeSurfaceMaterial.setColor(toCesiumProperty(WHITE));
        domeSurfaceMaterial.setCellAlpha(toCesiumProperty(0.0));
        sensorFieldOfViewGraphics.setDomeSurfaceMaterial(toCesiumProperty(domeSurfaceMaterial));
//        sensorFieldOfViewGraphics.setShow(toCesiumProperty(true));
        SolidColorMaterialGraphics lateralSurfaceMaterial = new SolidColorMaterialGraphics(new Color(m_satellite.getColor().getRed(),m_satellite.getColor().getGreen(),m_satellite.getColor().getBlue(),123));
        sensorFieldOfViewGraphics.setLateralSurfaceMaterial(toCesiumProperty(lateralSurfaceMaterial));
        getExtensions().add(new FieldOfViewGraphicsExtension(sensorFieldOfViewGraphics));
        getExtensions().add(new AccessConstraintsExtension());
    }

    /**
     * 配置传感器基础参数
     * @param type 输入传感器类型
     * @param halfAnglePara 参数数据同上
     */
    private void setSensorProp(SensorType type,Double halfAnglePara[]){
        if (type==SensorType.Rectangular) {
            RectangularPyramid fieldOfView = new RectangularPyramid();
            fieldOfView.setXHalfAngle(Trig.degreesToRadians(halfAnglePara[0]));
            fieldOfView.setYHalfAngle(Trig.degreesToRadians(halfAnglePara[1]));
            fieldOfView.setRadius(5000000.0);
            fieldOfViewExtension = new FieldOfViewExtension(fieldOfView);
            getExtensions().add(fieldOfViewExtension);
        }else if(type==SensorType.SimpleConic) {
            ComplexConic fieldOfView = new ComplexConic();
            double halfAngle =Trig.degreesToRadians(halfAnglePara[0]);
            fieldOfView.setClockAngles(0,TwoPi);
            fieldOfView.setHalfAngles(0,halfAngle);
            fieldOfView.setRadius(5000000.0);
            fieldOfViewExtension = new FieldOfViewExtension(fieldOfView);
            getExtensions().add(fieldOfViewExtension);
        }else if (type==SensorType.ComplexConic){
            ComplexConic fieldOfView = new ComplexConic();
            double innerHalfAngle = Trig.degreesToRadians(halfAnglePara[0]);
            double outerHalfAngle = Trig.degreesToRadians(halfAnglePara[1]);
            double minClockAngle = Trig.degreesToRadians(halfAnglePara[2]);
            double maxClockAngle = Trig.degreesToRadians(halfAnglePara[3]);
            fieldOfView.setClockAngles(minClockAngle,maxClockAngle);
            fieldOfView.setHalfAngles(innerHalfAngle,outerHalfAngle);
            fieldOfView.setRadius(5000000.0);
            fieldOfViewExtension = new FieldOfViewExtension(fieldOfView);
            getExtensions().add(fieldOfViewExtension);
        }
    }
//    public JSONArray getScanPlatform(PlatformCollection platformCollection){
//        return getScanPlatform(platformCollection,3.14/4);
//    }
    /**
     * 设置需要凝视的platform
     * @param platformCollection 需要扫描的platform集合
     */
    public JSONArray getScanPlatform(PlatformCollection platformCollection, boolean gaze, double minimumElevation){
        TimeIntervalCollection1<Axes> timeIntervalCollection1= new TimeIntervalCollection1<>();
        TimeIntervalCollection1<Platform> platformTimeIntervalCollection1 = new TimeIntervalCollection1<>();
        AccessQuery accessQueryShow = null;
        for (Platform platform :platformCollection.getItems()){
            LinkInstantaneous linkInstantaneous = new LinkInstantaneous(this,platform);
            linkInstantaneous.getExtensions().add(new IdentifierExtension("Sensor_"+this.getName()+"/"+"CentralBodySurfaceRegion_"+platform.getName()));

            if (gaze) {
                CentralBodySurfaceRegionElevationAngleConstraint m_accessQuery = new CentralBodySurfaceRegionElevationAngleConstraint(linkInstantaneous, RECEIVER, minimumElevation);
                AxesTargetingLink axesTargetingLink = new AxesTargetingLink(m_accessQuery.getConstrainedLink(), LinkRole.TRANSMITTER, new VectorFixed(getParent().getOrientationAxes(), Cartesian.toCartesian(UnitCartesian.getUnitZ())));
                TypeLiteral<AccessConstraintsExtension> typeLiteral2 = new TypeLiteral<AccessConstraintsExtension>() {
                };
                AccessConstraintCollection accessConstraintCollection = getExtensions().getByType(typeLiteral2).getConstraints();
                accessConstraintCollection.clear();

                if (accessQueryShow != null) {
                    accessQueryShow = new AccessQueryOr(m_accessQuery, accessQueryShow);
                } else {
                    accessQueryShow = m_accessQuery;
                }
                timeIntervalCollection1.add(new TimeIntervalCollection1<>(m_accessQuery.getEvaluator().evaluate(availableTime).getSatisfactionIntervals(), axesTargetingLink));
                platformTimeIntervalCollection1.add(new TimeIntervalCollection1<>(m_accessQuery.getEvaluator().evaluate(availableTime).getSatisfactionIntervals(), platform));
                accessConstraintCollection.add(m_accessQuery);
            }else{
                AccessQuery m_accessQuery = new CentralBodySurfaceRegionConstraint(platform,this);
                platformTimeIntervalCollection1.add(new TimeIntervalCollection1<>(m_accessQuery.getEvaluator().evaluate(availableTime).getSatisfactionIntervals(), platform));
            }

        }
        TypeLiteral<FieldOfViewGraphicsExtension> typeLiteral = new TypeLiteral<FieldOfViewGraphicsExtension>(){};
        SensorFieldOfViewGraphics fieldOfViewGraphics = getExtensions().getByType(typeLiteral).getFieldOfViewGraphics();
        if (accessQueryShow!=null) {
            timeIntervalCollection1.add(new TimeIntervalCollection1<>(
                    (new AccessQueryNot(accessQueryShow)).getEvaluator().evaluate(availableTime).getSatisfactionIntervals(),new AxesNorthEastDown(m_earth,getParent().getLocationPoint())));
            setOrientationAxes(new CompositeAxes(timeIntervalCollection1));
            fieldOfViewGraphics.setShow(new AccessQueryCesiumProperty<>(accessQueryShow, true, false, false));
        }else if (gaze){
            fieldOfViewGraphics.setShow(toCesiumProperty(false));
        }
        JSONArray jsonArray = new JSONArray();
        for(int i=0;i<platformTimeIntervalCollection1.size();i++){
            TimeInterval1<Platform> timeInterval= platformTimeIntervalCollection1.get(i);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("id",i);
            jsonObject.put("target",timeInterval.getData().getName());
            jsonObject.put("startTime",timeInterval.getStart().toDateTime());
            jsonObject.put("endTime",timeInterval.getStop().toDateTime());
            jsonObject.put("satName",getParent().getName());
            jsonObject.put("sensorName",getName());
            jsonObject.put("duration", timeInterval.toDuration().getSeconds());
            jsonArray.add(jsonObject);
        }
//        System.out.println(jsonArray);
        return jsonArray;
    }

    /**
     * 获取传感器方向单位四元数
     * @param minutes 采样时间间隔，单位s
     * @return 包含时间、单位四元数的JsonArray数据
     */
    public JSONArray getscanOrientation(double minutes){
        if (minutes==0)
            minutes = 5.0;
        Axes orientationAxes = getOrientationAxes();
//        System.out.println(orientationAxes);
//        TypeLiteral<FieldOfViewGraphicsExtension> typeLiteral = new TypeLiteral<FieldOfViewGraphicsExtension>(){};
//        SensorFieldOfViewGraphics fieldOfViewGraphics = getExtensions().getByType(typeLiteral).getFieldOfViewGraphics();
//        AccessQuery accessQuery= ((AccessQueryCesiumProperty) fieldOfViewGraphics.getShow()).getQuery();

        TimeIntervalCollection timeIntervalCollection = orientationAxes.getEvaluator().getAvailabilityIntervals();
        JSONArray jsonArray = new JSONArray();
        for (int i=0;i<timeIntervalCollection.size();i++){
            TimeInterval timeInterval = timeIntervalCollection.get(i);
            DateMotionCollection2<UnitQuaternion, Cartesian> dateMotionCollection2 = orientationAxes.getEvaluator().evaluate(timeInterval, Duration.fromMinutes(1), 0);
            List<JulianDate> julianDateList = dateMotionCollection2.getDates();
            List<UnitQuaternion> unitQuaternionsList = dateMotionCollection2.getValues();
            for (int j=0;j<julianDateList.size();j++){
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("Time",julianDateList.get(j));
                jsonObject.put("unitQuaternion",unitQuaternionsList.get(j));
                jsonArray.add(jsonObject);
            }
        }
//        System.out.println(jsonArray);
        return jsonArray;
    }


    /**
     *  获取扫描信息
     * @return 包含扫描开始时间，结束时间，卫星名称，传感器名称的JsonArray数据
     */
    public JSONArray getscanInfo(){
//        Axes orientationAxes = getOrientationAxes();
//        TimeIntervalCollection1<Axes> timeIntervalCollection = orientationAxes.getEvaluator().getDefinedInIntervals();

//        TimeIntervalCollection timeIntervalCollection = orientationAxes.getEvaluator().getAvailabilityIntervals();
        TypeLiteral<FieldOfViewGraphicsExtension> typeLiteral = new TypeLiteral<FieldOfViewGraphicsExtension>(){};
        SensorFieldOfViewGraphics fieldOfViewGraphics = getExtensions().getByType(typeLiteral).getFieldOfViewGraphics();
        AccessQuery accessQuery= ((AccessQueryCesiumProperty) fieldOfViewGraphics.getShow()).getQuery();
        TimeIntervalCollection timeIntervalCollection = accessQuery.getEvaluator().evaluate(availableTime).getSatisfactionIntervals();
        JSONArray jsonArray = new JSONArray();
        for(int i=0;i<timeIntervalCollection.size();i++){
            TimeInterval timeInterval= timeIntervalCollection.get(i);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("startTime",timeInterval.getStart().toString());
            jsonObject.put("endTime",timeInterval.getStop().toString());
            jsonObject.put("satName",getParent().getName());
            jsonObject.put("sensorName",getName());
            jsonArray.add(jsonObject);
        }
//        System.out.println(jsonArray);
        return jsonArray;
    }

    /**
     *  还没写呢
     */
    public void changeAxesofOrientation(){
        Axes axes = getOrientationAxes();
    }


    /**
     * 计算传感器得到的四个角点的数据
     * @return List<Cartographic> 四个位置点的列表
     */
    public List<Cartographic> getCurvesPoints()
    {
        TypeLiteral<FieldOfViewGraphicsExtension> typeLiteral = new TypeLiteral<FieldOfViewGraphicsExtension>(){};
        SensorFieldOfViewGraphics fieldOfViewGraphics = getExtensions().getByType(typeLiteral).getFieldOfViewGraphics();
        AccessQuery accessQuery= ((AccessQueryCesiumProperty) fieldOfViewGraphics.getShow()).getQuery();
        TimeIntervalCollection timeIntervalCollection = accessQuery.getEvaluator().evaluate(availableTime).getSatisfactionIntervals();
        SensorProjectionEvaluator projectionEvaluator =fieldOfViewExtension.getSensorProjectionEvaluator(m_earth);
        System.out.println(timeIntervalCollection.get(0).getStart());
        SensorProjection projection = projectionEvaluator.evaluate(timeIntervalCollection.get(0).getStart().addSeconds(1));
        List <SensorProjectionBoundary> sensorProjectionBoundaries = projection.getSurfaceBoundaries().getItems();
        List <Cartographic> cartographicList = new ArrayList<>();
        for (SensorProjectionBoundary sensorProjectionBoundary:sensorProjectionBoundaries){
            CurveCollection curves = sensorProjectionBoundary.getBoundaryCurveSegments();
            for(Curve curve: curves){
                cartographicList.add(m_earth.getShape().cartesianToCartographic(curve.getInitialPoint()));
//                cartographicList.add(m_earth.getShape().cartesianToCartographic(curve.getFinalPoint()));
                //只需要得到开始或结束中任意一个数据就行
//                System.out.println(m_earth.getShape().cartesianToCartographic(curve.getFinalPoint()));
            }
        }
        return cartographicList;
    }

}

package com.ruoyi.common.core.stkcomp.entity;

import agi.foundation.Bounds;
import agi.foundation.DateMotionCollection1;
import agi.foundation.access.*;
import agi.foundation.access.constraints.CentralBodyObstructionConstraint;
import agi.foundation.access.constraints.CentralBodySurfaceRegionSensorVolumeConstraint;
import agi.foundation.access.constraints.SensorVolumeConstraint;
import agi.foundation.celestial.CentralBodiesFacet;
import agi.foundation.celestial.EarthCentralBody;
import agi.foundation.cesium.*;
import agi.foundation.coordinates.Cartesian;
import agi.foundation.platforms.Platform;
import agi.foundation.platforms.PlatformCollection;
import agi.foundation.time.Duration;
import agi.foundation.time.JulianDate;
import agi.foundation.time.TimeInterval;
import agi.foundation.time.TimeIntervalCollection;
import fzyk.stkcomp.report.SceneReport;
import fzyk.stkcomp.report.SceneReportType;
import lombok.Data;

import javax.ws.rs.core.Link;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static agi.foundation.cesium.advanced.CesiumProperty.toCesiumProperty;

/**
 * @ClassName Access
 * @Description TODO
 * @author: ltq
 * @date 2022/9/21 09:31
 * @Version 1.0
 */
@Data
public class Access {

    private String name;

    private TimeInterval availableTime;

    private Platform source;

    private PlatformCollection targets;

    private AccessQuery accessQuery;

    private List<LinkInstantaneous> linkInstantaneousList = new ArrayList<>();
    private Color color =MyUtil.randomColor(255);
    private AccessConstraintCollection accessConstraints=new AccessConstraintCollection();

    static final EarthCentralBody m_earth = CentralBodiesFacet.getFromContext().getEarth();

    /**
     * 新建船
     * @param name 名称
     * @param availabileTime 可见时间
     * @param source
     * @param targets
     */
    public Access(String name, TimeInterval availabileTime,Platform source,PlatformCollection targets){
        setName(name);
        this.source = source;
        this.targets = targets;
        this.availableTime = availabileTime;
        for(int i=0;i<targets.size();i++){
            Platform target = targets.get(i);
            LinkInstantaneous linkInstantaneous = new LinkInstantaneous(source,target);
            linkInstantaneous.setName(source.getName() + "%" + target.getName());

            computeAccess(linkInstantaneous);
            linkInstantaneousList.add(linkInstantaneous);
        }


    }
    public void computeAccess(LinkInstantaneous linkInstantaneous){
//        if(source.getClass().getSimpleName().equals("Sensor")){
//            System.out.println(((Sensor)source).getFieldOfViewExtension().getFieldOfViewVolume());
//            SensorVolumeConstraint sensorVolumeConstraint = new SensorVolumeConstraint(source,LinkRole.TRANSMITTER);
//            accessConstraints.add(sensorVolumeConstraint);
//        }

        CentralBodyObstructionConstraint centralBodyObstructionConstraint = new CentralBodyObstructionConstraint(linkInstantaneous,m_earth);
        accessConstraints.add(centralBodyObstructionConstraint);
//        for(TimeInterval timeInterval1: new AccessQueryAnd(accessConstraints).getEvaluator().evaluate(availableTime).getSatisfactionIntervals()){
//            System.out.println(timeInterval1);
//        }
    }
    public void setViews(SceneView sceneView) {
        color = sceneView.getColor();
        for(int i=0;i<linkInstantaneousList.size();i++){
            // Configure graphical display of the access link.
            LinkGraphics linkGraphics = new LinkGraphics();
            // Show the access link only when access is satisfied.
            linkGraphics.setShow(new AccessQueryCesiumProperty<>(accessConstraints.get(i), true, false, false));
            linkGraphics.setMaterial(toCesiumProperty(new SolidColorMaterialGraphics(color)));
//        linkGraphics.setShow(toCesiumProperty(sceneView.isOrbitLineShow()));
            linkInstantaneousList.get(i).getExtensions().add(new LinkGraphicsExtension(linkGraphics));
        }
    }

    /**
     * 获取可见性报告根据Access类型报告格式修改
     * @param timeInterval
     * @return
     */
    public SceneReport getAccessReport(TimeInterval timeInterval){
        TimeIntervalCollection timeIntervalCollection = new AccessQueryAnd(accessConstraints).getEvaluator().evaluate(timeInterval).getSatisfactionIntervals();
        SceneReport sceneReport = new SceneReport();
        sceneReport.setType(SceneReportType.Access);
        sceneReport.setTimeInterval(timeInterval);
//        sceneReport.setStep(step);
        sceneReport.setPointNum(timeIntervalCollection.size());
        List<ArrayList<String>> data = new ArrayList<>();
        for (int i = 0;i<timeIntervalCollection.size();i++){
            ArrayList<String> dataRow = new ArrayList<>();
            dataRow.add(source.getName());
            dataRow.add(targets.get(0).getName());
            dataRow.add(String.valueOf(timeIntervalCollection.get(i).getStart()));
            dataRow.add(String.valueOf(timeIntervalCollection.get(i).getStop()));
            dataRow.add(String.valueOf(timeIntervalCollection.get(i).toDuration().getTotalSeconds()));
            data.add(dataRow);
        }
        sceneReport.setData(data);
        return sceneReport;
    }

    public SceneReport getAccessReport2(TimeInterval timeInterval){
        List<ArrayList<String>> data = new ArrayList<>();
        SceneReport sceneReport = new SceneReport();
        sceneReport.setType(SceneReportType.Access);
        sceneReport.setTimeInterval(timeInterval);
//        sceneReport.setStep(step);
        int count = 0;
//        int num = 0;
        for (LinkInstantaneous linkInstantaneous : linkInstantaneousList) {
//            num += 1;
//            System.out.println(num);
//            System.out.println(count);
//            AccessConstraintCollection accessConstraints=new AccessConstraintCollection();
//            CentralBodyObstructionConstraint centralBodyObstructionConstraint = new CentralBodyObstructionConstraint(linkInstantaneous, m_earth);
            SensorVolumeConstraint sensorVolumeConstraint = new SensorVolumeConstraint(linkInstantaneous,LinkRole.TRANSMITTER);
//            accessConstraints.add(centralBodyObstructionConstraint);
//            accessConstraints.add(sensorVolumeConstraint);
            TimeIntervalCollection timeIntervalCollection = sensorVolumeConstraint.getEvaluator().evaluate(timeInterval).getSatisfactionIntervals();
            count += timeIntervalCollection.size();
            String[] names = linkInstantaneous.getName().split("%");
//            System.out.println(names[0]);
            String sourceName = names[0];
            String targetName = names[1];
            for (TimeInterval interval : timeIntervalCollection) {
                ArrayList<String> dataRow = new ArrayList<>();
                dataRow.add(sourceName);
                dataRow.add(targetName);
                dataRow.add(String.valueOf(interval.getStart().toDateTime().toInstant()));
                dataRow.add(String.valueOf(interval.getStop().toDateTime().toInstant()));
                dataRow.add(String.valueOf(interval.toDuration().getTotalSeconds()));
                data.add(dataRow);
            }

        }
        sceneReport.setPointNum(count);
        sceneReport.setData(data);
        return sceneReport;
    }



}

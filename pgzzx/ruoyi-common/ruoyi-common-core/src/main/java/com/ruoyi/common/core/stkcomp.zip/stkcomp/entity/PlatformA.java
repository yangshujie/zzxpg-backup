package com.ruoyi.common.core.stkcomp.entity;

import agi.foundation.TypeLiteral;
import agi.foundation.access.AccessConstraint;
import agi.foundation.access.AccessConstraintCollection;
import agi.foundation.celestial.CentralBodiesFacet;
import agi.foundation.celestial.EarthCentralBody;
import agi.foundation.infrastructure.IdentifierExtension;
import agi.foundation.platforms.AccessConstraintsExtension;
import agi.foundation.platforms.Platform;
import agi.foundation.time.TimeInterval;
import lombok.Data;

import java.awt.*;

/**
 * @ClassName PlatFormA
 * @Description TODO
 * @author: ltq
 * @date 2022/9/26 16:14
 * @Version 1.0
 */
@Data
public class PlatformA extends Platform {
    static EarthCentralBody m_earth = CentralBodiesFacet.getFromContext().getEarth();

    public Color color;

    public TimeInterval availableTime;
    public String modelName;
    private String id;

    private boolean labelShow;

    public void setId(String id) {
        this.id = id;
        getExtensions().add(new IdentifierExtension(id));
    }

    public void getConstraintsCollection(){
        TypeLiteral<AccessConstraintsExtension> typeLiteral2 = new TypeLiteral<AccessConstraintsExtension>() {};
        AccessConstraintCollection accessConstraintCollection = getExtensions().getByType(typeLiteral2).getConstraints();
        if (accessConstraintCollection!=null){
            for (AccessConstraint accessConstraint:accessConstraintCollection){
                System.out.println(accessConstraint.getClass().getSimpleName());
            }
        }

    }




}

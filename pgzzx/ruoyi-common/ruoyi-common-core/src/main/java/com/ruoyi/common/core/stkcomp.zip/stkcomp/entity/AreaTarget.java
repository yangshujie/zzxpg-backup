package com.ruoyi.common.core.stkcomp.entity;

import agi.foundation.Bounds;
import agi.foundation.Trig;
import agi.foundation.cesium.*;
import agi.foundation.coordinates.Cartesian;
import agi.foundation.coordinates.Cartographic;
import agi.foundation.coordinates.LongitudeLatitudeRadius;
import agi.foundation.geometry.PointCartographic;
import agi.foundation.geometry.discrete.SurfaceShapes;
import agi.foundation.platforms.CentralBodySurfaceRegion;
import agi.foundation.platforms.PlatformCollection;
import lombok.Data;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static agi.foundation.cesium.advanced.CesiumProperty.toCesiumProperty;
import static fzyk.stkcomp.entity.MyUtil.randomColor;
import static java.awt.Color.WHITE;


/**
 * @ClassName AreaTarget
 * @Description TODO
 * @date 2022/7/18 13:15
 * @Version 1.0
 */
@Data
public class AreaTarget extends PlatformA {


    private CentralBodySurfaceRegion centralBodySurfaceRegion;

    /**
     * 新建目标区域
     * @param name 区域名称
     * @param cartographicList 区域点列表
     */
    public AreaTarget(String name, List<Cartographic> cartographicList){
        super();
        setName(name);
        centralBodySurfaceRegion =new CentralBodySurfaceRegion(m_earth,cartographicList);
        getExtensions().add(centralBodySurfaceRegion);
        //设置区域中心点做为显示
        setLocationPoint(new PointCartographic(m_earth,centralBodySurfaceRegion.getSurfaceRegion().getCentroid()));
    }

    public AreaTarget(String name,Cartographic center,double majorAxisRadius,double minorAxisRadius,double bearing){
        setName(name);
        List<Cartographic> cartographicList = new ArrayList<>();
        System.out.println(""+center+"  "+majorAxisRadius+"  "+minorAxisRadius+"   "+Trig.radiansToDegrees(bearing));
        List<Cartesian> cartesianList = SurfaceShapes.computeEllipseCartographic(m_earth,center,majorAxisRadius,minorAxisRadius, Trig.radiansToDegrees(bearing)).getPositions();
        for (Cartesian cartesian:cartesianList){
            LongitudeLatitudeRadius longitudeLatitudeRadius = new LongitudeLatitudeRadius(cartesian);
            cartographicList.add(new Cartographic(longitudeLatitudeRadius.getLongitude(),longitudeLatitudeRadius.getLatitude(),0));
        }
        centralBodySurfaceRegion =new CentralBodySurfaceRegion(m_earth,cartographicList);
        getExtensions().add(centralBodySurfaceRegion);
        System.out.println(centralBodySurfaceRegion.getSurfaceRegion().getCentroid().getLongitude());
        System.out.println(centralBodySurfaceRegion.getSurfaceRegion().getCentroid().getLatitude());
        //设置区域中心点做为显示
        setLocationPoint(new PointCartographic(m_earth,centralBodySurfaceRegion.getSurfaceRegion().getCentroid()));
    }

    public void setViews() {
        setViews(new SceneView());
    }

    public void setViews(SceneView sceneView) {

        color = sceneView.getColor();
        Color aColor = new Color(color.getRed(),color.getGreen(),color.getBlue(),100);
        //标签显示
        LabelGraphics labelGraphics = new LabelGraphics();
        labelGraphics.setText(toCesiumProperty(getName()));
        labelGraphics.setFillColor(toCesiumProperty(color));
        labelGraphics.setFont(toCesiumProperty("15px"));
        labelGraphics.setDistanceDisplayCondition(toCesiumProperty(new Bounds(1000.0, Double.MAX_VALUE)));
        labelGraphics.setShow(toCesiumProperty(sceneView.isLabelShow()));
        getExtensions().add(new LabelGraphicsExtension(labelGraphics));

        //区域中心点
//        PointGraphics pointGraphics = new PointGraphics();
//        pointGraphics.setColor(toCesiumProperty(color));
//        pointGraphics.setPixelSize(toCesiumProperty(2.0));
//        getExtensions().add(new PointGraphicsExtension(pointGraphics));

        //区域绘制
        CentralBodySurfaceRegionGraphics centralBodySurfaceRegionGraphics= new CentralBodySurfaceRegionGraphics();
        centralBodySurfaceRegionGraphics.setOutline(toCesiumProperty(true));
//        centralBodySurfaceRegionGraphics.setOutlineWidth(toCesiumProperty(10.0));
        centralBodySurfaceRegionGraphics.setOutlineColor(toCesiumProperty(aColor));
        centralBodySurfaceRegionGraphics.setHeight(toCesiumProperty(0.0));
        centralBodySurfaceRegionGraphics.setMaterial(toCesiumProperty(new SolidColorMaterialGraphics(aColor)));
//        centralBodySurfaceRegionGraphics.setFill(toCesiumProperty(true));
        getExtensions().add(new CentralBodySurfaceRegionGraphicsExtension(centralBodySurfaceRegionGraphics));
    }

    /**
     *
     * @param shpUtil
     * @return
     */
    static public PlatformCollection getPlatformCollection(ShpUtil shpUtil){
        PlatformCollection platformCollection =new PlatformCollection();
        for (List<Cartographic> cartographics :shpUtil.getAreaList()){
            AreaTarget areaTarget = new AreaTarget(shpUtil.getName(),cartographics);
            platformCollection.add(areaTarget);
        }
        return platformCollection;
    }
}

package com.ruoyi.common.core.stkcomp.entity;

import agi.foundation.Bounds;
import agi.foundation.cesium.*;
import agi.foundation.coordinates.Cartographic;
import agi.foundation.geometry.AxesEastNorthUp;
import agi.foundation.geometry.Point;
import agi.foundation.geometry.PointCartographic;
import agi.foundation.time.TimeInterval;
import lombok.Data;

import java.awt.*;

import static agi.foundation.cesium.advanced.CesiumProperty.toCesiumProperty;


/**
 * @ClassName Target
 * @Description TODO
 * @author: ltq
 * @date 2022/9/23 09:57
 * @Version 1.0
 */
@Data
public class Target extends PlatformA {

    private Double lon;

    private Double lat;


    public Target(){
        this("Target",new Cartographic(0,0,0),null);
    }

    public Target(String name,Cartographic location,TimeInterval availableTime){
        super();
        setName(name);
        setModelName("target.gltf");
        lon = location.getLongitude();
        lat = location.getLatitude();
        Point locationPoint = new PointCartographic(m_earth, location);
        setLocationPoint(locationPoint);
        this.availableTime = availableTime;
        // Orient the facility using East-North-Up (ENU) axes.
        setOrientationAxes(new AxesEastNorthUp(m_earth, locationPoint));
        // Configure a glTF model for the facility.
        ModelGraphics modelGraphics = new ModelGraphics();

        // Link to a binary glTF file.
        modelGraphics.setModel(toCesiumProperty(new CesiumResource(MyUtil.getModelUrl()+modelName, CesiumResourceBehavior.LINK_TO)));
        modelGraphics.setHeightReference(toCesiumProperty(CesiumHeightReference.CLAMP_TO_GROUND));
        modelGraphics.setRunAnimations(toCesiumProperty(false));
        modelGraphics.setScale(toCesiumProperty(32.0));
        modelGraphics.setMinimumPixelSize(toCesiumProperty(32.0));
        getExtensions().add(new ModelGraphicsExtension(modelGraphics));
    }

    public void setViews() {
        setViews(new SceneView());
    }
    public void setViews(SceneView sceneView) {

        color = sceneView.getColor();
        Color aColor = new Color(color.getRed(),color.getGreen(),color.getBlue(),100);
        //��ǩ��ʾ
        LabelGraphics labelGraphics = new LabelGraphics();
        labelGraphics.setText(toCesiumProperty(getName()));
        labelGraphics.setFillColor(toCesiumProperty(color));
        labelGraphics.setFont(toCesiumProperty("15px"));
        labelGraphics.setDistanceDisplayCondition(toCesiumProperty(new Bounds(1000.0, Double.MAX_VALUE)));
        labelGraphics.setShow(toCesiumProperty(sceneView.isLabelShow()));
        getExtensions().add(new LabelGraphicsExtension(labelGraphics));

        // ����ģ��
        setModelName("target.gltf");
        ModelGraphics modelGraphics = new ModelGraphics();
        modelGraphics.setModel(toCesiumProperty(new CesiumResource(MyUtil.getModelUrl()+modelName, CesiumResourceBehavior.LINK_TO)));
        modelGraphics.setRunAnimations(toCesiumProperty(false));
        labelGraphics.setShow(toCesiumProperty(sceneView.isModelShow()));
        getExtensions().add(new ModelGraphicsExtension(modelGraphics));

    }





}

package com.ruoyi.common.core.stkcomp.entity;

import agi.foundation.DateMotionCollection1;
import agi.foundation.DateMotionCollection2;
import agi.foundation.Trig;
import agi.foundation.TypeLiteral;
import agi.foundation.access.*;
import agi.foundation.access.constraints.CentralBodyObstructionConstraint;
import agi.foundation.access.constraints.CentralBodySurfaceRegionConstraint;
import agi.foundation.access.constraints.CentralBodySurfaceRegionElevationAngleConstraint;
import agi.foundation.access.constraints.SensorVolumeConstraint;
import agi.foundation.cesium.*;
import agi.foundation.coordinates.*;
import agi.foundation.geometry.*;
import agi.foundation.geometry.shapes.*;
import agi.foundation.infrastructure.IdentifierExtension;
import agi.foundation.platforms.*;
import agi.foundation.stk.StkAttitudeFile;
import agi.foundation.stk.StkAttitudeFileOptions;
import agi.foundation.time.*;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import fzyk.stkcomp.report.SceneReport;
import fzyk.stkcomp.report.SceneReportType;
import lombok.Data;

import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import static agi.foundation.Constants.HalfPi;
import static agi.foundation.Constants.TwoPi;
import static agi.foundation.access.LinkRole.RECEIVER;
import static agi.foundation.cesium.advanced.CesiumProperty.toCesiumProperty;
import static agi.foundation.coordinates.EulerSequenceIndicator.EULER232;
import static agi.foundation.coordinates.EulerSequenceIndicator.EULER321;
import static java.awt.Color.WHITE;


/**
 * @ClassName Sensor
 * @Description TODO
 * @date 2022/7/15 10:45
 * @Version 1.0
 */
@Data
public class Sensor extends PlatformA {

    public FieldOfViewExtension fieldOfViewExtension;
    public SensorType sensorType;
    /**
     * 新建Sensor  默认Rectangular类型[4.0, 8.5]
     * @param m_satellite sensor关联卫星
     * @param sensorName sensor名称
     */
    public Sensor(Satellite m_satellite,String sensorName){
        this(m_satellite,sensorName,SensorType.Rectangular, new Double[]{4.0, 8.5});
    }

    /**
     * 新建Sensor
     * @param platform sensor关联卫星
     * @param sensorName  sensor名称
     * @param type        类型
     * @param halfAnglePara 输入传感器相关数据  Rectangular 类型需要输入xyHalfAngle两个角度值  SimpleConic 类型需要输入一个halfAngle角度值   ComplexConic 需要innerHalfAngle，outerHalfAngle，minClockAngle，maxClockAngle四个
     */
    public Sensor(Satellite platform,String sensorName,SensorType type,Double halfAnglePara[]){
        super();
        setLocationPoint(platform.getLocationPoint());
        availableTime = platform.getAvailableTime();
        sensorType = type;
        getExtensions().add(new CesiumAvailabilityExtension(new TimeIntervalCollection(availableTime)));
        // Orient the sensor to target the link with the satellite.
        //sensor指向目标卫星方向
//        m_satlliteSensor.setOrientationAxes(new AxesTargetingLink(m_satelliteFacilityLink, LinkRole.TRANSMITTER,
//                new VectorFixed(m_facility.getOrientationAxes(), Cartesian.toCartesian(UnitCartesian.getUnitZ()))));
        setParent(platform);
//        setOrientationAxes(new AxesNorthEastDown(m_earth,platform.getLocationPoint()));
        setPointingFromAzEl(0.0,90.0);
//        System.out.println(sensor);
//        m_satlliteSensor.getExtensions().add(new IdentifierExtension("Sensor_"+sensor.getString("sensorName")));
        setName(sensorName);

        setSensorProp(type,halfAnglePara,platform.getModifiedKeplerianElements().getRadiusOfPeriapsis());
        color =new Color(platform.getColor().getRed(),platform.getColor().getGreen(),platform.getColor().getBlue(),123);
        getExtensions().add(new AccessConstraintsExtension());
    }


    public void setViews() {
        setViews(new SceneView());
    }


    public void setViews(SceneView sceneView) {
        if(sceneView.getLength()!=null)  fieldOfViewExtension.getFieldOfViewVolume().setRadius(sceneView.getLength());
        // Configure graphical display of the sensor.
        SensorFieldOfViewGraphics sensorFieldOfViewGraphics = new SensorFieldOfViewGraphics();
//        AccessQuery m_accessQuery = new CentralBodyObstructionConstraint(m_satelliteFacilityLink, m_earth);
//        // Show the sensor only when access is satisfied.
//        sensorFieldOfViewGraphics.setShow(new AccessQueryCesiumProperty<>(m_accessQuery, true, false, false));
        sensorFieldOfViewGraphics.setShow(toCesiumProperty(sceneView.isSensorShow()));
        GridMaterialGraphics domeSurfaceMaterial = new GridMaterialGraphics();
        domeSurfaceMaterial.setColor(toCesiumProperty(WHITE));
        domeSurfaceMaterial.setCellAlpha(toCesiumProperty(0.0));
        sensorFieldOfViewGraphics.setDomeSurfaceMaterial(toCesiumProperty(domeSurfaceMaterial));
//        sensorFieldOfViewGraphics.setShow(toCesiumProperty(true));
        SolidColorMaterialGraphics lateralSurfaceMaterial = new SolidColorMaterialGraphics(color);
        sensorFieldOfViewGraphics.setLateralSurfaceMaterial(toCesiumProperty(lateralSurfaceMaterial));
        getExtensions().add(new FieldOfViewGraphicsExtension(sensorFieldOfViewGraphics));
    }


    /**
     * 配置传感器基础参数
     * @param type 输入传感器类型
     * @param halfAnglePara 参数数据同上
     */
    private void setSensorProp(SensorType type,Double halfAnglePara[],double radius){
        if (type==SensorType.Rectangular) {
            RectangularPyramid fieldOfView = new RectangularPyramid();
            fieldOfView.setXHalfAngle(Trig.degreesToRadians(halfAnglePara[0]));
            fieldOfView.setYHalfAngle(Trig.degreesToRadians(halfAnglePara[1]));
            fieldOfView.setRadius(radius);
            fieldOfViewExtension = new FieldOfViewExtension(fieldOfView);
            getExtensions().add(fieldOfViewExtension);
        }else if(type==SensorType.SimpleConic) {
            ComplexConic fieldOfView = new ComplexConic();
            double halfAngle =Trig.degreesToRadians(halfAnglePara[0]);
            fieldOfView.setClockAngles(0,TwoPi);
            fieldOfView.setHalfAngles(0,halfAngle);
            fieldOfView.setRadius(radius);
            fieldOfViewExtension = new FieldOfViewExtension(fieldOfView);
            getExtensions().add(fieldOfViewExtension);
        }else if (type==SensorType.ComplexConic){
            ComplexConic fieldOfView = new ComplexConic();
            double innerHalfAngle = Trig.degreesToRadians(halfAnglePara[0]);
            double outerHalfAngle = Trig.degreesToRadians(halfAnglePara[1]);
            double minClockAngle = Trig.degreesToRadians(halfAnglePara[2]);
            double maxClockAngle = Trig.degreesToRadians(halfAnglePara[3]);
            fieldOfView.setClockAngles(minClockAngle,maxClockAngle);
            fieldOfView.setHalfAngles(innerHalfAngle,outerHalfAngle);
            fieldOfView.setRadius(radius);
            fieldOfViewExtension = new FieldOfViewExtension(fieldOfView);
            getExtensions().add(fieldOfViewExtension);
        }
//        getExtensions().add(accessConstraintsExtension);
    }

    public void setPointingFromAzEl(Double azimuth,Double elevation){
        ElementaryRotation elementaryRotation1 = new ElementaryRotation(AxisIndicator.SECOND,Trig.degreesToRadians(azimuth));
        ElementaryRotation elementaryRotation2 = new ElementaryRotation(AxisIndicator.THIRD,Trig.degreesToRadians(elevation)-HalfPi);
//        AngleAxisRotation angleAxisRotation = new AngleAxisRotation(a,);
        UnitQuaternion unitQuaternion1 = new UnitQuaternion(elementaryRotation1).multiply(new UnitQuaternion(elementaryRotation2));
//        UnitQuaternion unitQuaternion2 = new UnitQuaternion(new YawPitchRoll(0.0,0.0,3.14/4, YawPitchRollIndicator.YPR));
        setOrientationAxes(new AxesFixedOffset(getParent().getOrientationAxes(),unitQuaternion1));
    }
    public void setPointingFromUnitQuaternion(Double x,Double y,Double z,Double w){

        UnitQuaternion unitQuaternion1 = new UnitQuaternion(w,x,y,z);
//        UnitQuaternion unitQuaternion2 = new UnitQuaternion(new YawPitchRoll(0.0,0.0,3.14/4, YawPitchRollIndicator.YPR));
        setOrientationAxes(new AxesFixedOffset(getParent().getOrientationAxes(),unitQuaternion1));
    }
    public void setPointingFromEuler(Double first,Double second,Double third,String sequence){
        EulerSequenceIndicator eulerSequenceIndicator = null;
        switch (sequence){
            case "121":eulerSequenceIndicator = EulerSequenceIndicator.EULER121;break;
            case "123":eulerSequenceIndicator = EulerSequenceIndicator.EULER123;break;
            case "131":eulerSequenceIndicator = EulerSequenceIndicator.EULER131;break;
            case "132":eulerSequenceIndicator = EulerSequenceIndicator.EULER132;break;
            case "212":eulerSequenceIndicator = EulerSequenceIndicator.EULER212;break;
            case "213":eulerSequenceIndicator = EulerSequenceIndicator.EULER213;break;
            case "231":eulerSequenceIndicator = EulerSequenceIndicator.EULER231;break;
            case "232":eulerSequenceIndicator = EulerSequenceIndicator.EULER232;break;
            case "312":eulerSequenceIndicator = EulerSequenceIndicator.EULER312;break;
            case "313":eulerSequenceIndicator = EulerSequenceIndicator.EULER313;break;
            case "321":eulerSequenceIndicator = EulerSequenceIndicator.EULER321;break;
            case "323":eulerSequenceIndicator = EulerSequenceIndicator.EULER323;break;
        }
        EulerSequence eulerSequence = new EulerSequence(first,second,third,eulerSequenceIndicator);
        setOrientationAxes(new AxesFixedOffset(getParent().getOrientationAxes(),new UnitQuaternion(eulerSequence)));
    }
    public void setPointingFromFile(String path){
        InputStream inputStream = MyUtil.getFile(path);
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            StkAttitudeFileOptions stkAttitudeFileOptions = new StkAttitudeFileOptions();
            stkAttitudeFileOptions.setIgnoreUnsupportedProperties(true);
            stkAttitudeFileOptions.setIgnorePropertiesWithUnsupportedValues(true);
            StkAttitudeFile stkAttitudeFile = StkAttitudeFile.readFrom(reader,stkAttitudeFileOptions);
            Axes axes = stkAttitudeFile.getData().createAxes();
            ((AxesInterpolator)axes).setReferenceAxes(getParent().getOrientationAxes());
            setOrientationAxes(axes);
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public void setPointingFromTargeted(PlatformCollection platformCollection){
        System.out.println("setPointingFromTargeted");
        AccessQuery accessQueryShow = null;
        TimeIntervalCollection1<Axes> timeIntervalCollection1= new TimeIntervalCollection1<>();
        for (Platform platform :platformCollection.getItems()){
            LinkInstantaneous linkInstantaneous = new LinkInstantaneous(this,platform);
            AccessQuery accessQuery = null;
            AxesTargetingLink axesTargetingLink =null;
//            System.out.println(platform.getClass().getSimpleName());
//            if(platform.getClass().getSimpleName().equals("AreaTarget")){
//                accessQuery = new CentralBodySurfaceRegionConstraint(((AreaTarget)platform).getCentralBodySurfaceRegion(), getParent());
//                axesTargetingLink = new AxesTargetingLink(linkInstantaneous, LinkRole.TRANSMITTER, new VectorFixed(getParent().getOrientationAxes(), Cartesian.toCartesian(UnitCartesian.getUnitZ())));
//                System.out.println(accessQuery.getEvaluator().evaluate(availableTime).getSatisfactionIntervals().size());
//            }else{
                accessQuery = new CentralBodyObstructionConstraint(linkInstantaneous,m_earth);
                axesTargetingLink = new AxesTargetingLink(linkInstantaneous, LinkRole.TRANSMITTER, new VectorFixed(getParent().getOrientationAxes(), Cartesian.toCartesian(UnitCartesian.getUnitZ())));
//            }
            if (accessQueryShow != null) {
                accessQueryShow = new AccessQueryOr(accessQuery, accessQueryShow);
            } else {
                accessQueryShow = accessQuery;
            }

            timeIntervalCollection1.add(new TimeIntervalCollection1<>(accessQuery.getEvaluator().evaluate(availableTime).getSatisfactionIntervals(), axesTargetingLink));
        }
        setOrientationAxes(new CompositeAxes(timeIntervalCollection1));
        TypeLiteral<FieldOfViewGraphicsExtension> typeLiteral = new TypeLiteral<FieldOfViewGraphicsExtension>(){};
        SensorFieldOfViewGraphics fieldOfViewGraphics = getExtensions().getByType(typeLiteral).getFieldOfViewGraphics();
        fieldOfViewGraphics.setShow(new AccessQueryCesiumProperty<>(accessQueryShow, true, false, false));
    }


    /**
     * 设置需要凝视的platform
     * @param platformCollection 需要扫描的platform集合
     */
    public JSONArray getScanPlatform(PlatformCollection platformCollection, boolean gaze, double minimumElevation){
        TimeIntervalCollection1<Axes> timeIntervalCollection1= new TimeIntervalCollection1<>();
        TimeIntervalCollection1<Platform> platformTimeIntervalCollection1 = new TimeIntervalCollection1<>();
        AccessQuery accessQueryShow = null;
        for (Platform platform :platformCollection.getItems()){
            LinkInstantaneous linkInstantaneous = new LinkInstantaneous(this,platform);
            linkInstantaneous.getExtensions().add(new IdentifierExtension("Sensor_"+this.getName()+"/"+"CentralBodySurfaceRegion_"+platform.getName()));

            if (gaze) {
                CentralBodySurfaceRegionElevationAngleConstraint m_accessQuery = new CentralBodySurfaceRegionElevationAngleConstraint(linkInstantaneous, RECEIVER, minimumElevation);
                AxesTargetingLink axesTargetingLink = new AxesTargetingLink(m_accessQuery.getConstrainedLink(), LinkRole.TRANSMITTER, new VectorFixed(getParent().getOrientationAxes(), Cartesian.toCartesian(UnitCartesian.getUnitZ())));
                TypeLiteral<AccessConstraintsExtension> typeLiteral2 = new TypeLiteral<AccessConstraintsExtension>() {};
                AccessConstraintCollection accessConstraintCollection = getExtensions().getByType(typeLiteral2).getConstraints();
                accessConstraintCollection.clear();

                if (accessQueryShow != null) {
                    accessQueryShow = new AccessQueryOr(m_accessQuery, accessQueryShow);
                } else {
                    accessQueryShow = m_accessQuery;
                }
                timeIntervalCollection1.add(new TimeIntervalCollection1<>(m_accessQuery.getEvaluator().evaluate(availableTime).getSatisfactionIntervals(), axesTargetingLink));
                platformTimeIntervalCollection1.add(new TimeIntervalCollection1<>(m_accessQuery.getEvaluator().evaluate(availableTime).getSatisfactionIntervals(), platform));
                accessConstraintCollection.add(m_accessQuery);
            }else{
                AccessQuery m_accessQuery = new CentralBodySurfaceRegionConstraint(platform,this);
                platformTimeIntervalCollection1.add(new TimeIntervalCollection1<>(m_accessQuery.getEvaluator().evaluate(availableTime).getSatisfactionIntervals(), platform));
            }

        }
        TypeLiteral<FieldOfViewGraphicsExtension> typeLiteral = new TypeLiteral<FieldOfViewGraphicsExtension>(){};
        SensorFieldOfViewGraphics fieldOfViewGraphics = getExtensions().getByType(typeLiteral).getFieldOfViewGraphics();
        if (accessQueryShow!=null) {
            timeIntervalCollection1.add(new TimeIntervalCollection1<>(
                    (new AccessQueryNot(accessQueryShow)).getEvaluator().evaluate(availableTime).getSatisfactionIntervals(),new AxesNorthEastDown(m_earth,getParent().getLocationPoint())));
            setOrientationAxes(new CompositeAxes(timeIntervalCollection1));
            fieldOfViewGraphics.setShow(new AccessQueryCesiumProperty<>(accessQueryShow, true, false, false));
        }else if (gaze){
            fieldOfViewGraphics.setShow(toCesiumProperty(false));
        }
        JSONArray jsonArray = new JSONArray();
        for(int i=0;i<platformTimeIntervalCollection1.size();i++){
            TimeInterval1<Platform> timeInterval= platformTimeIntervalCollection1.get(i);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("id",i);
            jsonObject.put("target",timeInterval.getData().getName());
            jsonObject.put("startTime",timeInterval.getStart().toDateTime());
            jsonObject.put("endTime",timeInterval.getStop().toDateTime());
            jsonObject.put("satName",getParent().getName());
            jsonObject.put("sensorName",getName());
            jsonObject.put("duration", timeInterval.toDuration().getSeconds());
            jsonArray.add(jsonObject);
        }
//        System.out.println(jsonArray);
        return jsonArray;
    }

    /**
     * 获取传感器方向单位四元数
     * @param minutes 采样时间间隔，单位s
     * @return 包含时间、单位四元数的JsonArray数据
     */
    public JSONArray getscanOrientation(double minutes){
        if (minutes==0)
            minutes = 5.0;
        Axes orientationAxes = getOrientationAxes();
//        System.out.println(orientationAxes);
//        TypeLiteral<FieldOfViewGraphicsExtension> typeLiteral = new TypeLiteral<FieldOfViewGraphicsExtension>(){};
//        SensorFieldOfViewGraphics fieldOfViewGraphics = getExtensions().getByType(typeLiteral).getFieldOfViewGraphics();
//        AccessQuery accessQuery= ((AccessQueryCesiumProperty) fieldOfViewGraphics.getShow()).getQuery();

        TimeIntervalCollection timeIntervalCollection = orientationAxes.getEvaluator().getAvailabilityIntervals();
        JSONArray jsonArray = new JSONArray();
        for (int i=0;i<timeIntervalCollection.size();i++){
            TimeInterval timeInterval = timeIntervalCollection.get(i);
            DateMotionCollection2<UnitQuaternion, Cartesian> dateMotionCollection2 = orientationAxes.getEvaluator().evaluate(timeInterval, Duration.fromMinutes(1), 0);
            List<JulianDate> julianDateList = dateMotionCollection2.getDates();
            List<UnitQuaternion> unitQuaternionsList = dateMotionCollection2.getValues();
            for (int j=0;j<julianDateList.size();j++){
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("Time",julianDateList.get(j));
                jsonObject.put("unitQuaternion",unitQuaternionsList.get(j));
                jsonArray.add(jsonObject);
            }
        }
//        System.out.println(jsonArray);
        return jsonArray;
    }


    /**
     *  获取扫描信息
     * @return 包含扫描开始时间，结束时间，卫星名称，传感器名称的JsonArray数据
     */
    public JSONArray getscanInfo(){
//        Axes orientationAxes = getOrientationAxes();
//        TimeIntervalCollection1<Axes> timeIntervalCollection = orientationAxes.getEvaluator().getDefinedInIntervals();

//        TimeIntervalCollection timeIntervalCollection = orientationAxes.getEvaluator().getAvailabilityIntervals();
        TypeLiteral<FieldOfViewGraphicsExtension> typeLiteral = new TypeLiteral<FieldOfViewGraphicsExtension>(){};
        SensorFieldOfViewGraphics fieldOfViewGraphics = getExtensions().getByType(typeLiteral).getFieldOfViewGraphics();
        AccessQuery accessQuery= ((AccessQueryCesiumProperty) fieldOfViewGraphics.getShow()).getQuery();
        TimeIntervalCollection timeIntervalCollection = accessQuery.getEvaluator().evaluate(availableTime).getSatisfactionIntervals();
        JSONArray jsonArray = new JSONArray();
        for(int i=0;i<timeIntervalCollection.size();i++){
            TimeInterval timeInterval= timeIntervalCollection.get(i);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("startTime",timeInterval.getStart().toString());
            jsonObject.put("endTime",timeInterval.getStop().toString());
            jsonObject.put("satName",getParent().getName());
            jsonObject.put("sensorName",getName());
            jsonArray.add(jsonObject);
        }
//        System.out.println(jsonArray);
        return jsonArray;
    }

    /**
     * 载荷实时角度变化
     * @param timeInterval
     * @param step
     * @return
     */


    public SceneReport getUnitQuaternionReport(TimeInterval timeInterval, Duration step){
        DateMotionCollection2<UnitQuaternion,Cartesian>	dateMotionCollection2 = getOrientationAxes().getEvaluator().evaluate(timeInterval,step,0);
        List<JulianDate> julianDateList = dateMotionCollection2.getDates();
        List<UnitQuaternion> unitQuaternionList = dateMotionCollection2.getValues();
        SceneReport sceneReport = new SceneReport();
        sceneReport.setType(SceneReportType.Body_Axes_Orientation);
        sceneReport.setTimeInterval(timeInterval);
        sceneReport.setStep(step);
        sceneReport.setPointNum(julianDateList.size());
        List<ArrayList<String>> data = new ArrayList<>();
        for (int i = 0;i<julianDateList.size();i++){
            ArrayList<String> dataRow = new ArrayList<>();
            dataRow.add(julianDateList.get(i).toDateTime().toString());
            dataRow.add(String.valueOf(unitQuaternionList.get(i).getX()));
            dataRow.add(String.valueOf(unitQuaternionList.get(i).getY()));
            dataRow.add(String.valueOf(unitQuaternionList.get(i).getZ()));
            dataRow.add(String.valueOf(unitQuaternionList.get(i).getW()));
            data.add(dataRow);
        }
        sceneReport.setData(data);
        return sceneReport;
    }

    public SceneReport getEulerAngleReport(TimeInterval timeInterval, Duration step){
        DateMotionCollection2<UnitQuaternion,Cartesian>	dateMotionCollection2 = getOrientationAxes().getEvaluator().evaluate(timeInterval,step,0);
        List<JulianDate> julianDateList = dateMotionCollection2.getDates();
        List<UnitQuaternion> unitQuaternionList = dateMotionCollection2.getValues();
        SceneReport sceneReport = new SceneReport();
        sceneReport.setType(SceneReportType.Euler_Angle);
        sceneReport.setTimeInterval(timeInterval);
        sceneReport.setStep(step);
        sceneReport.setPointNum(julianDateList.size());
        List<ArrayList<String>> data = new ArrayList<>();
        for (int i = 0;i<julianDateList.size();i++){
            ArrayList<String> dataRow = new ArrayList<>();
            EulerSequence eulerSequence = new EulerSequence(unitQuaternionList.get(i),EULER321);
            dataRow.add(julianDateList.get(i).toDateTime().toString());
            dataRow.add(String.valueOf(eulerSequence.getFirstRotation()));
            dataRow.add(String.valueOf(eulerSequence.getSecondRotation()));
            dataRow.add(String.valueOf(eulerSequence.getThirdRotation()));
            data.add(dataRow);
        }
        sceneReport.setData(data);
        return sceneReport;
    }


    public SceneReport getAzElReport(TimeInterval timeInterval, Duration step){
        DateMotionCollection2<UnitQuaternion,Cartesian>	dateMotionCollection2 = getOrientationAxes().getEvaluator().evaluate(timeInterval,step,0);
        List<JulianDate> julianDateList = dateMotionCollection2.getDates();
        List<UnitQuaternion> unitQuaternionList = dateMotionCollection2.getValues();
        SceneReport sceneReport = new SceneReport();
        sceneReport.setType(SceneReportType.Boresight_AzEl);
        sceneReport.setTimeInterval(timeInterval);
        sceneReport.setStep(step);
        sceneReport.setPointNum(julianDateList.size());
        List<ArrayList<String>> data = new ArrayList<>();
        for (int i = 0;i<julianDateList.size();i++){
            ArrayList<String> dataRow = new ArrayList<>();
            EulerSequence eulerSequence = new EulerSequence(unitQuaternionList.get(i),EULER232);
            dataRow.add(julianDateList.get(i).toDateTime().toString());
            Double azimuth=90-Trig.radiansToDegrees(eulerSequence.getSecondRotation().getAngle());
            Double elevation=Trig.radiansToDegrees(eulerSequence.getThirdRotation().getAngle());
            dataRow.add(String.valueOf(elevation>0?elevation:(elevation+180)));
            dataRow.add(String.valueOf(azimuth));
            data.add(dataRow);
        }
        sceneReport.setData(data);
        return sceneReport;
    }

    public SceneReport getCurvesPointsReport(TimeInterval timeInterval, Duration step){
        DateMotionCollection1<SensorProjection> dateMotionCollection1 = fieldOfViewExtension.getSensorProjectionEvaluator(m_earth).evaluate(timeInterval,step);
        List<JulianDate> julianDateList = dateMotionCollection1.getDates();
        List<SensorProjection> sensorProjectionList = dateMotionCollection1.getValues();
        SceneReport sceneReport = new SceneReport();
        sceneReport.setType(SceneReportType.Curves_Points);
        sceneReport.setTimeInterval(timeInterval);
        sceneReport.setStep(step);
        sceneReport.setPointNum(julianDateList.size());
        List<ArrayList<String>> data = new ArrayList<>();
        for(int i=0;i<julianDateList.size();i++){
            ArrayList<String> dataRow = new ArrayList<>();
            List <SensorProjectionBoundary> sensorProjectionBoundaries = sensorProjectionList.get(i).getSurfaceBoundaries().getItems();
            SensorProjectionBoundary sensorProjectionBoundary = sensorProjectionBoundaries.get(0);
            CurveCollection curves = sensorProjectionBoundary.getBoundaryCurveSegments();
            List<Cartographic> cartographicList = new ArrayList<>();
            for(Curve curve: curves){
                cartographicList.add(m_earth.getShape().cartesianToCartographic(curve.getInitialPoint()));
            }
            dataRow.add(julianDateList.get(i).toDateTime().toString());
            for(int j=0;j<8;j++){
                if(j>=cartographicList.size()){
                    dataRow.add("");
                    dataRow.add("");
                }else{
                    dataRow.add(String.valueOf(Trig.radiansToDegrees(cartographicList.get(j).getLatitude())));
                    dataRow.add(String.valueOf(Trig.radiansToDegrees(cartographicList.get(j).getLongitude())));
                }
            }
            data.add(dataRow);
        }
        System.out.println(data.size());
        sceneReport.setData(data);
        return sceneReport;
    }

    /**
     *  还没写呢
     */
    public void changeAxesofOrientation(){
        Axes axes = getOrientationAxes();
    }


    /**
     * 计算传感器得到的四个角点的数据
     * @return List<Cartographic> 四个位置点的列表
     */
    public List<Cartographic> getCurvesPoints()
    {
        TypeLiteral<FieldOfViewGraphicsExtension> typeLiteral = new TypeLiteral<FieldOfViewGraphicsExtension>(){};
        SensorFieldOfViewGraphics fieldOfViewGraphics = getExtensions().getByType(typeLiteral).getFieldOfViewGraphics();
        AccessQuery accessQuery= ((AccessQueryCesiumProperty) fieldOfViewGraphics.getShow()).getQuery();
        TimeIntervalCollection timeIntervalCollection = accessQuery.getEvaluator().evaluate(availableTime).getSatisfactionIntervals();
        SensorProjectionEvaluator projectionEvaluator =fieldOfViewExtension.getSensorProjectionEvaluator(m_earth);
        System.out.println(timeIntervalCollection.get(0).getStart());
        SensorProjection projection = projectionEvaluator.evaluate(timeIntervalCollection.get(0).getStart().addSeconds(1));
        List <SensorProjectionBoundary> sensorProjectionBoundaries = projection.getSurfaceBoundaries().getItems();
        List <Cartographic> cartographicList = new ArrayList<>();
        for (SensorProjectionBoundary sensorProjectionBoundary:sensorProjectionBoundaries){
            CurveCollection curves = sensorProjectionBoundary.getBoundaryCurveSegments();
            for(Curve curve: curves){
                cartographicList.add(m_earth.getShape().cartesianToCartographic(curve.getInitialPoint()));
//                cartographicList.add(m_earth.getShape().cartesianToCartographic(curve.getFinalPoint()));
                //只需要得到开始或结束中任意一个数据就行
//                System.out.println(m_earth.getShape().cartesianToCartographic(curve.getFinalPoint()));
            }
        }
        return cartographicList;
    }

}

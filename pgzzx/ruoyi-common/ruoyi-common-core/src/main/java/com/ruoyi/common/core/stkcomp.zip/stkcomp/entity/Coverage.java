package com.ruoyi.common.core.stkcomp.entity;

import agi.foundation.Trig;
import agi.foundation.TypeLiteral;
import agi.foundation.access.AccessQuery;
import agi.foundation.access.AccessQueryAnd;
import agi.foundation.access.LinkInstantaneous;
import agi.foundation.access.constraints.CentralBodyObstructionConstraint;
import agi.foundation.coverage.AssetDefinition;
import agi.foundation.coverage.CoverageGridPointWithResults;
import agi.foundation.coverage.CoverageResults;
import agi.foundation.coverage.ParameterizedTemporallyPartitionedCoverageDefinition;
import agi.foundation.coverage.figureofmerit.NumberOfAssets;
import agi.foundation.coverage.figureofmerit.RevisitTime;
import agi.foundation.geometry.discrete.SurfaceRegionsCoverageGrid;
import agi.foundation.geometry.shapes.EllipsoidSurfaceRegion;
import agi.foundation.platforms.AccessConstraintsExtension;
import agi.foundation.platforms.CentralBodySurfaceRegion;
import agi.foundation.platforms.Platform;
import agi.foundation.platforms.PlatformCollection;
import agi.foundation.time.Duration;
import agi.foundation.time.TimeInterval;
import agi.foundation.time.TimeIntervalCollection;
import fzyk.stkcomp.report.SceneReport;
import fzyk.stkcomp.report.SceneReportType;

import java.util.ArrayList;
import java.util.List;


/**
 * @author zl
 * 覆盖模块
 */
public class Coverage extends PlatformA{

    private TimeInterval timeInterval;

    private List<Platform> assetsPlatformList;

    private List<Platform> areaTargetPlatformList;

    private Double degree;

    private String computeType;

    private String dataType;

    private ParameterizedTemporallyPartitionedCoverageDefinition coverageDefinition;

    private List<EllipsoidSurfaceRegion> areaTargetSurfaceRegionList;

//    public Coverage(String name, TimeInterval timeInterval, PlatformCollection assetsList, PlatformCollection areaList, int degree){
//        createCoverageDefinition(assetsList, areaList, degree);
//    }

    /**
     * 新建覆盖模型
     * @param assetsPlatformList 扫描对象
     * @param areaTargetPlatformList 扫描区域
     * @return
     */
    public Coverage(String name, List<Platform> assetsPlatformList, List<Platform> areaTargetPlatformList, Double degree, String computeType, String dataType){

        super.setName(name);
        this.assetsPlatformList = assetsPlatformList;
        this.areaTargetPlatformList = areaTargetPlatformList;
        this.computeType = computeType;
        this.dataType = dataType;
        this.degree = degree;
//        List<Double> list = new ArrayList<>();
        List<EllipsoidSurfaceRegion> areaTargetSurfaceRegionList = new ArrayList<>();
        for (int i=0;i<areaTargetPlatformList.size();i++){
//            TypeLiteral<CentralBodySurfaceRegion> typeLiteral = new TypeLiteral<CentralBodySurfaceRegion>(){};
////            System.out.println(areaTargetPlatformList.get(i));
//            EllipsoidSurfaceRegion areaTargetSurfaceRegion= areaTargetPlatformList.get(i).getExtensions().getByType(typeLiteral).getSurfaceRegion();  //
//            areaTargetSurfaceRegionList.add(areaTargetSurfaceRegion);
            areaTargetSurfaceRegionList.add(((AreaTarget)areaTargetPlatformList.get(i)).getCentralBodySurfaceRegion().getSurfaceRegion());

        }
        System.out.println(areaTargetSurfaceRegionList);
        this.areaTargetSurfaceRegionList = areaTargetSurfaceRegionList;
//        SurfaceRegionsCoverageGrid surfaceRegionsCoverageGrid = new SurfaceRegionsCoverageGrid(Trig.degreesToRadians(1), m_earth, areaTargetSurfaceRegionList);
        SurfaceRegionsCoverageGrid surfaceRegionsCoverageGrid = meshGrid(degree, areaTargetSurfaceRegionList);
        ParameterizedTemporallyPartitionedCoverageDefinition coverage = new ParameterizedTemporallyPartitionedCoverageDefinition(surfaceRegionsCoverageGrid,true);  //

        for (Platform platform : assetsPlatformList) {

//            Sensor sensor = new Sensor(platform, "sensor", SensorType.Rectangular, )
            // Create a new link between your satellite and the grid by using the placeholder
            // satellite is the transmitter, grid is the receiver
            LinkInstantaneous newLink = new LinkInstantaneous(platform, coverage.getGridPointPlaceholder());

            // Apply a sensor volume constraint to the grid (receiver)
            CentralBodyObstructionConstraint centralBodyObstructionConstraint = new CentralBodyObstructionConstraint(newLink,m_earth);

            TypeLiteral<AccessConstraintsExtension> typeLiteral = new TypeLiteral<AccessConstraintsExtension>(){};
            AccessQuery accessQuery = centralBodyObstructionConstraint;  //链路本身的可见约束
            boolean isRequired = false;
            if(platform.getExtensions().getByType(typeLiteral)!=null) {
                for (AccessQuery accessQuery2 : platform.getExtensions().getByType(typeLiteral).getConstraints()) { //每个平台实体的约束，需要区分约束类型吗
                    accessQuery = new AccessQueryAnd(accessQuery, accessQuery2);  // 两个约束的交集
                }
            }
            coverage.addAsset(new AssetDefinition(platform, accessQuery, isRequired)); // isRequired  false 的意义
//            coverage.addAsset(new AssetDefinition(platform, centralBodyObstructionConstraint, isRequired));

        }
        this.coverageDefinition = coverage;
    }

    /**
     * 覆盖模型划分网格
     * @param degree 经纬度采样间隔
     * @param areaTargetSurfaceRegionList 目标区域列表
     * @return 带网格的区域列表
     */
    public SurfaceRegionsCoverageGrid meshGrid(Double degree, List<EllipsoidSurfaceRegion> areaTargetSurfaceRegionList){
        try {
            return new SurfaceRegionsCoverageGrid(Trig.degreesToRadians(degree), m_earth, areaTargetSurfaceRegionList);
        }catch (Exception e){
            System.out.println(e.toString());
            return null;
        }
    }


    /**
     * 计算覆盖结果
     * @param timeInterval 计算时间段
     * @param step 网格计算的时间采样间隔
     * @return 每个网格计算下来的最大重访时间或最小覆盖重数
     */
    public SceneReport computeResult(TimeInterval timeInterval, Duration step){
        try{

//            SurfaceRegionsCoverageGrid surfaceRegionsCoverageGrid = meshGrid(this.degree, this.areaTargetSurfaceRegionList);
//            ParameterizedTemporallyPartitionedCoverageDefinition coverage = new ParameterizedTemporallyPartitionedCoverageDefinition(surfaceRegionsCoverageGrid,true);  //
//
//            for (Platform platform : this.assetsPlatformList) {
//
////            Sensor sensor = new Sensor(platform, "sensor", SensorType.Rectangular, )
//                // Create a new link between your satellite and the grid by using the placeholder
//                // satellite is the transmitter, grid is the receiver
//                LinkInstantaneous newLink = new LinkInstantaneous(platform, coverage.getGridPointPlaceholder());
//
//                // Apply a sensor volume constraint to the grid (receiver)
//                CentralBodyObstructionConstraint centralBodyObstructionConstraint = new CentralBodyObstructionConstraint(newLink,m_earth);
//
//                TypeLiteral<AccessConstraintsExtension> typeLiteral = new TypeLiteral<AccessConstraintsExtension>(){};
//                AccessQuery accessQuery = centralBodyObstructionConstraint;  //链路本身的可见约束
//                boolean isRequired = false;
//                if(platform.getExtensions().getByType(typeLiteral)!=null) {
//                    for (AccessQuery accessQuery2 : platform.getExtensions().getByType(typeLiteral).getConstraints()) { //每个平台实体的约束，需要区分约束类型吗
//                        accessQuery = new AccessQueryAnd(accessQuery, accessQuery2);  // 两个约束的交集
//                    }
//                }
//                coverage.addAsset(new AssetDefinition(platform, accessQuery, isRequired)); // isRequired  false 的意义
////            coverage.addAsset(new AssetDefinition(platform, centralBodyObstructionConstraint, isRequired));
//
//            }
//            this.coverageDefinition = coverage;
//            double computeResult = 0;

            List<ArrayList<String>> coverageResultMList = new ArrayList<>();
            SceneReport sceneReport = new SceneReport();
//            CoverageResultM coverageResultM = new CoverageResultM();
            int number = 0;
//            System.out.println("1111111111111111111111");
            //计算需要时间
            CoverageResults coverageResults = this.coverageDefinition.computeCoverageOverTheGrid(new TimeIntervalCollection(timeInterval), step);  //
//            System.out.println("22222222222222222222222");
            switch (this.computeType) {
                case "revisitTime":
                    for (CoverageGridPointWithResults coverageGridPointWithResults : coverageResults.getGridPoints()) {
                        double result = 0;
                        ArrayList<String> resultList = new ArrayList<>();
                        if (this.dataType.equals("max")) {
//                            computeResult = Math.max(computeResult, RevisitTime.maximumRevisitTime(coverageGridPointWithResults.getAssetCoverage()));
//                            System.out.println(computeResult);
                            result = RevisitTime.maximumRevisitTime(coverageGridPointWithResults.getAssetCoverage());
                        }
                        if (this.dataType.equals("min")) {
//                            computeResult = Math.max(computeResult, RevisitTime.minimumRevisitTime(coverageGridPointWithResults.getAssetCoverage()));
//                            System.out.println(computeResult);
                            result = RevisitTime.minimumRevisitTime(coverageGridPointWithResults.getAssetCoverage());
                        }
                        if (this.dataType.equals("average")) {
//                            computeResult = Math.max(computeResult, RevisitTime.averageRevisitTime(coverageGridPointWithResults.getAssetCoverage()));
//                            System.out.println(computeResult);
                            result = RevisitTime.averageRevisitTime(coverageGridPointWithResults.getAssetCoverage());
                        }
                        number += 1;
                        resultList.add(String.valueOf(number));
                        resultList.add(String.valueOf(result));
                        coverageResultMList.add(resultList);
                    }
                    break;
                case "nNumberAssets":
//                    computeResult = NumberOfAssets.minimumNumberOfAssets(coverageResults.getGridPoints().get(0).getAssetCoverage());
                    for (CoverageGridPointWithResults coverageGridPointWithResults :coverageResults.getGridPoints()){
                        double result = 0;
                        ArrayList<String> resultList = new ArrayList<>();
                        if (this.dataType.equals("max")) {
//                            computeResult = Math.min(computeResult, NumberOfAssets.maximumNumberOfAssets(coverageGridPointWithResults.getAssetCoverage()));
                            result = (double) NumberOfAssets.maximumNumberOfAssets(coverageGridPointWithResults.getAssetCoverage());
                        }
                        if (this.dataType.equals("min")) {
//                            computeResult = Math.min(computeResult, NumberOfAssets.minimumNumberOfAssets(coverageGridPointWithResults.getAssetCoverage()));
                            result = (double) NumberOfAssets.minimumNumberOfAssets(coverageGridPointWithResults.getAssetCoverage());
                        }
                        if (this.dataType.equals("average")) {
//                            computeResult = Math.min(computeResult, NumberOfAssets.averageNumberOfAssets(coverageGridPointWithResults.getAssetCoverage()));
                            result = NumberOfAssets.averageNumberOfAssets(coverageGridPointWithResults.getAssetCoverage());
                        }
                        number += 1;
                        resultList.add(String.valueOf(number));
                        resultList.add(String.valueOf(result));
                        coverageResultMList.add(resultList);
                    }
                    break;
            }
            sceneReport.setName(super.getName() + "_" + this.computeType);
            sceneReport.setData(coverageResultMList);
            sceneReport.setPointNum(number);
            sceneReport.setStep(step);
            sceneReport.setTimeInterval(timeInterval);
            sceneReport.setType(SceneReportType.Figures_Of_Merit);
            return sceneReport;
        }catch (Exception e){
            System.out.println(e.toString());
            return null;
        }
    }
}

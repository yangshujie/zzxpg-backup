package com.ruoyi.common.core.stkcomp.report;

import agi.foundation.time.Duration;
import agi.foundation.time.TimeInterval;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static fzyk.utils.csvFileUtils.createCSVFile;

/**
 * @ClassName SceneReport
 * @Description TODO
 * @author: ltq
 * @date 2022/12/7 10:53
 * @Version 1.0
 */
@Data
public class SceneReport {
    //报告名称
    private String name;
    //创建时间
    private Date createTime = new Date();
    //场景名称
    //private String sceneName;
    //数据开始/结束时间
    private TimeInterval timeInterval;
    //数据结束时间
//    private JulianDate endTime;
    //采样间隔
    private Duration step;
    //采样点个数
    private Integer pointNum;
    //报告类型 后面换成enum
    private SceneReportType type;
    //报告对应的数据名称列表
    //private List<String> colNameList;
    //对应二维数组
    private List<ArrayList<String>> data;

    public JSONArray toJSONArray(){
        JSONArray jsonArray = new JSONArray();
        for (int i = 0;i<pointNum;i++){
            JSONObject jsonObject = new JSONObject();
            for(int j =0;j<type.getColKeyList().size();j++){
                jsonObject.put(type.getColKeyList().get(j),data.get(i).get(j));
            }
            jsonArray.add(jsonObject);
        }
        return jsonArray;
    }
//    public File getCsvFile(String path){
//        return createCSVFile(type.getColNameList(),data,path,name);
//    }



}

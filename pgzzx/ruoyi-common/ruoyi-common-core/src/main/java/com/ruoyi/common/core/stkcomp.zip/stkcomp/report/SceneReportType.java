package com.ruoyi.common.core.stkcomp.report;

import fzyk.stkcomp.SceneException;
import lombok.Data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @ClassName SceneReportType
 * @Description TODO
 * @author: ltq
 * @date 2022/12/7 11:55
 * @Version 1.0
 */
@Data
public class SceneReportType {
    private final String name;

    private final List<String> colKeyList;
    private final List<String> colNameList;
    private SceneReportType(String name,List<String> colKeyList,List<String> colNameList){
        this.name = name;
        this.colNameList = colNameList;
        this.colKeyList = colKeyList;

    }

    public SceneReportType getSceneReportType(String name){
        switch(name){
            case "J2000PositionVelocity":  return J2000PositionVelocity;
            case "FixedPositionVelocity": return FixedPositionVelocity;
            case "SolarAER":  return Solar_AER;
            case "BoresightAzEl":  return Boresight_AzEl;
            case "EulerAngle":  return Euler_Angle;
            case "BodyAxesOrientation":  return Body_Axes_Orientation;
            case "CurvesPoints":  return Curves_Points;
            case "Access": return Access;
			case "FiguresOfMerit": return Figures_Of_Merit;
        }
        throw new SceneException("不存在相关报告");
    }
    //实体位置、速度信息
    public static final SceneReportType J2000PositionVelocity = new SceneReportType("J2000PositionVelocity",new ArrayList<>( Arrays.asList ("time","x","y","z")),new ArrayList<>( Arrays. asList ("time","x(m)","y(m)","z(m)")));
    public static final SceneReportType FixedPositionVelocity = new SceneReportType("FixedPositionVelocity",new ArrayList<>( Arrays.asList ("time","x","y","z")),new ArrayList<>( Arrays. asList ("time","x(m)","y(m)","z(m)")));
    public static final SceneReportType Solar_AER = new SceneReportType("Solar_AER",new ArrayList<>( Arrays. asList ("time","SOZ","SOA")),new ArrayList<>( Arrays. asList ("时间","太阳方位角(deg)","太阳高度角(deg)")));
    public static final SceneReportType Boresight_AzEl = new SceneReportType("Boresight_AzEl",new ArrayList<>( Arrays. asList ("time","azimuth","elevation")),new ArrayList<>( Arrays. asList ("时间","方位角(deg)","高度角(deg)")));
    public static final SceneReportType Euler_Angle = new SceneReportType("Eular_Angle",new ArrayList<>( Arrays. asList ("time","First","Second","Third")),new ArrayList<>( Arrays. asList ("时间","First(deg)","Second(deg)","Third(deg)")));
    public static final SceneReportType Body_Axes_Orientation = new SceneReportType("Body_Axes_Orientation",new ArrayList<>( Arrays. asList ("time","x","y","z","w")),new ArrayList<>( Arrays. asList ("时间","x(m)","y(m)","z(m)","w(m)")));
    public static final SceneReportType Curves_Points = new SceneReportType("Curves_Points",new ArrayList<>( Arrays. asList ("time","lon1","lat1","lon2","lat2","lon3","lat3","lon4","lat4")),new ArrayList<>( Arrays. asList ("时间","lon1(deg)","lat1(deg)","lon2(deg)","lat2(deg)","lon3(deg)","lat3(deg)","lon4(deg)","lat4(deg)")));
    /*
    Access类型的report字段修改
     */
    public static final SceneReportType Access = new SceneReportType("Access",new ArrayList<>( Arrays.asList ("sensorId","targetId","startTime","stopTime","duration")),new ArrayList<>( Arrays. asList ("载荷ID","目标ID","开始时间","结束时间","时间长度(s)")));
	public static final SceneReportType Figures_Of_Merit = new SceneReportType("FiguresOfMerit", new ArrayList<>(Arrays.asList("gridNumber", "value")), new ArrayList<>(Arrays.asList("网格序号", "覆盖效能")));


}

package com.ruoyi.common.core.stkcomp.entity;

/**
 * 传感器的三种枚举类型
 */
public enum SensorType {
    SimpleConic, ComplexConic, Rectangular
}

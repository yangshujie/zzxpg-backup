package com.ruoyi.common.core.stkcomp.entity;

import agi.foundation.*;
import agi.foundation.celestial.CentralBodiesFacet;
import agi.foundation.celestial.EarthGravitationalModel2008;
import agi.foundation.celestial.SunCentralBody;
import agi.foundation.cesium.*;
import agi.foundation.coordinates.*;
import agi.foundation.geometry.Point;
import agi.foundation.geometry.*;
import agi.foundation.platforms.PlatformCollection;
import agi.foundation.propagators.*;
import agi.foundation.stk.*;
import agi.foundation.time.Duration;
import agi.foundation.time.JulianDate;
import agi.foundation.time.TimeInterval;
import agi.foundation.time.TimeIntervalCollection;
import com.ruoyi.common.core.stkcomp.report.SceneReport;
import com.ruoyi.common.core.stkcomp.report.SceneReportType;
import lombok.Data;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import static agi.foundation.cesium.advanced.CesiumProperty.toCesiumProperty;


/**
 * @ClassName Satellite
 * @Description TODO
 * @date 2022/7/15 14:39
 * @Version 1.0
 */
@Data
public class Satellite extends PlatformA {

    //卫星轨道推进器
    private CartesianOnePointPropagator propagator;

    //为了星座先放这里
    public ModifiedKeplerianElements modifiedKeplerianElements;

    //目前需求  是四个推进器   外加六根树
    public Satellite(String name, String propagatorName, Double semimajorAxis, Double eccentricity, Double inclination, Double argumentOfPeriapsis, Double rightAscensionOfAscendingNode, Double trueAnomaly, TimeInterval availableTime) {
        super();
        setName(name);
//        propagatorName = "agi.foundation.propagators." + propagatorName;
//        Class propagtorClass = Class.forName(propagatorName);
//        Constructor constructor =propagtorClass.getConstructor();
        if (availableTime==null){
            JulianDate start_epoch = new JulianDate(ZonedDateTime.now());
            availableTime = new  TimeInterval(start_epoch,start_epoch.addDays(1));
        }
        this.availableTime = availableTime;
        KeplerianElements keplerianElements = new KeplerianElements(semimajorAxis,eccentricity, Trig.degreesToRadians(inclination),Trig.degreesToRadians(argumentOfPeriapsis),Trig.degreesToRadians(rightAscensionOfAscendingNode),Trig.degreesToRadians(trueAnomaly), EarthGravitationalModel2008.GravitationalParameter);
        switch (propagatorName){
            case "TwoBody":
                propagator = new TwoBodyPropagator(availableTime.getStart(),m_earth.getJ2000Frame(),keplerianElements);
                break;
            case "J2":
                propagator = new J2Propagator(availableTime.getStart(),
                        m_earth.getJ2000Frame(),
                        keplerianElements,EarthGravitationalModel2008.J2UnnormalizedValue,
                        EarthGravitationalModel2008.SemimajorAxis);
                break;
            case  "J4":
                propagator = new J4Propagator(availableTime.getStart(),
                        m_earth.getJ2000Frame(),
                        keplerianElements, EarthGravitationalModel2008.J2UnnormalizedValue,
                        EarthGravitationalModel2008.J4UnnormalizedValue,
                        EarthGravitationalModel2008.SemimajorAxis);
                break;
        }
        modifiedKeplerianElements = new ModifiedKeplerianElements(keplerianElements);
        Point locationPoint = propagator.createPoint();
        setLocationPoint(locationPoint);
        setOrientationAxes(new AxesVehicleVelocityLocalHorizontal(m_earth.getInertialFrame(), locationPoint));
    }
    //先放在这里  如果存表的话估计用不到这个
    public Satellite(String name,CartesianOnePointPropagator propagator,ModifiedKeplerianElements modifiedKeplerianElements,TimeInterval availableTime) {
        super();
        setName(name);
        this.availableTime = availableTime;
        this.modifiedKeplerianElements = modifiedKeplerianElements;
        this.setPropagator(propagator);
        Point locationPoint = propagator.createPoint();
        setLocationPoint(locationPoint);
        setOrientationAxes(new AxesVehicleVelocityLocalHorizontal(m_earth.getInertialFrame(), locationPoint));
    }
    /**
     * 根据sscNumber 新建一个卫星
     * @param name 卫星名称
     * @param id sscNumber
     * @param availableTime 可见时间
     */
    public Satellite(String name, String id, TimeInterval availableTime, Boolean isSSCNumber){
        super();
        setName(name);
        if (availableTime==null){
            JulianDate start_epoch = new JulianDate(ZonedDateTime.now());
            availableTime = new  TimeInterval(start_epoch,start_epoch.addDays(1));
        }
        this.availableTime = availableTime;
        if (isSSCNumber) {
            ArrayList<TwoLineElementSet> tleList = getTles(id);
            propagator =  new Sgp4Propagator(tleList);
            modifiedKeplerianElements = new ModifiedKeplerianElements(propagator.getEvaluator().evaluate(tleList.get(0).getEpoch(),0),EarthGravitationalModel2008.GravitationalParameter);
        }else {
            TwoLineElementSet tle = new TwoLineElementSet(id);
            propagator = new Sgp4Propagator(tle);
            modifiedKeplerianElements = new ModifiedKeplerianElements(propagator.getEvaluator().evaluate(tle.getEpoch(),0),EarthGravitationalModel2008.GravitationalParameter);
        }
        Point locationPoint = propagator.createPoint();
        setLocationPoint(locationPoint);
        setOrientationAxes(new AxesVehicleVelocityLocalHorizontal(m_earth.getInertialFrame(), locationPoint));
    }

    public Satellite(String name,String path){
        super();
        setName(name);
        InputStream inputStream = MyUtil.getFile(path);
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            StkEphemerisFileOptions stkEphemerisFileOptions = new StkEphemerisFileOptions();
            stkEphemerisFileOptions.setIgnoreUnsupportedProperties(true);
            stkEphemerisFileOptions.setIgnorePropertiesWithUnsupportedValues(true);
            StkEphemerisFile stkEphemerisFile = StkEphemerisFile.readFrom(reader,stkEphemerisFileOptions);
            StkEphemerisFile.Ephemeris ephemeris = stkEphemerisFile.getData();
            List<JulianDate> julianDateList = ephemeris.getTimes();
            this.availableTime =  new  TimeInterval(julianDateList.get(0),julianDateList.get(julianDateList.size()-1));;
            Point locationPoint = stkEphemerisFile.createPoint();
            modifiedKeplerianElements = new ModifiedKeplerianElements(ephemeris.getInterpolator().getData().getMotions().get(0),EarthGravitationalModel2008.GravitationalParameter);
            setLocationPoint(locationPoint);
            setOrientationAxes(new AxesVehicleVelocityLocalHorizontal(m_earth.getInertialFrame(),locationPoint));
        }catch (Exception e){
            System.out.println(e);
        }
    }
	
	    /**
     * 根据轨道高度和升交点地方时创建太阳同步轨道
     * @param name 卫星名称
     * @param orbitEpoch 历元时刻
     * @param altitude 轨道距地面高度，单位m
     * @param ascendingNodeLocalTime 升交点时间，单位s
     * @param timeInterval 可见时间
     */
    public Satellite(String name, JulianDate orbitEpoch, double altitude, Duration ascendingNodeLocalTime, TimeInterval timeInterval){
        super();
        setName(name);
        propagator = SpecializedOrbitSolver.createEarthSunSynchronousOrbitUsingAltitude(orbitEpoch, altitude, ascendingNodeLocalTime);
        this.availableTime = timeInterval;
        Point locationPoint = propagator.createPoint();
        modifiedKeplerianElements = ((J2Propagator)propagator).getInitialConditions();
        setLocationPoint(locationPoint);
        setOrientationAxes(new AxesVehicleVelocityLocalHorizontal(m_earth.getInertialFrame(), locationPoint));
    }

    /**
     * 根据近地点高度和升交点赤经创建太阳同步轨道
     * @param name 卫星名称
     * @param orbitEpoch 轨道历元时刻
     * @param periapsisAltitude 近地点高度
     * @param ascendingNodeLongitude 升交点赤经
     * @param timeInterval 轨道可见时间
     */
    public Satellite(String name, JulianDate orbitEpoch, double periapsisAltitude, double ascendingNodeLongitude, TimeInterval timeInterval){
        super();
        setName(name);
        propagator = SpecializedOrbitSolver.createEarthCriticallyInclinedSunSynchronousOrbit(orbitEpoch, periapsisAltitude, ascendingNodeLongitude);
        this.availableTime = timeInterval;
        Point locationPoint = propagator.createPoint();
        setLocationPoint(locationPoint);
        modifiedKeplerianElements = ((J2Propagator)propagator).getInitialConditions();
        setOrientationAxes(new AxesVehicleVelocityLocalHorizontal(m_earth.getInertialFrame(), locationPoint));
    }

    /**
     * 根据星下点经度创建地球同步轨道
     * @param name 卫星名称
     * @param orbitEpoch 历元时刻
     * @param stationaryLongitude 星下点经度
     * @param timeInterval 可见时间
     */
    public Satellite(String name, JulianDate orbitEpoch, double stationaryLongitude, TimeInterval timeInterval){
        super();
        setName(name);
        propagator = SpecializedOrbitSolver.createGeostationaryOrbit(orbitEpoch, stationaryLongitude);
        this.availableTime = timeInterval;
        Point locationPoint = propagator.createPoint();
        setLocationPoint(locationPoint);
        modifiedKeplerianElements = ((J2Propagator)propagator).getInitialConditions();
        setOrientationAxes(new AxesVehicleVelocityLocalHorizontal(m_earth.getInertialFrame(), locationPoint));
    }

    /**
     * 读文件库中的卫星数据
     * @param satelliteIdentifier
     * @return
     */
    private ArrayList<TwoLineElementSet> getTles(String satelliteIdentifier) {
//        注释部分为在线获取二行数据
        try {
            ArrayList<TwoLineElementSet> tleList = TwoLineElementSet.downloadTles(satelliteIdentifier, availableTime.getStart(),availableTime.getStop());
//            period = 86400/tleList.get(0).getMeanMotion();
            return tleList;
        } catch (DataUnavailableException e) {
        // Read from local data if the machine does not have access to the internet.
        ArrayList<TwoLineElementSet> result = new ArrayList<>();
        StkSatelliteDatabase satelliteDatabase = new StkSatelliteDatabase("SatelliteDatabase", "stkAllTLE");
        StkSatelliteDatabaseQuery query = new StkSatelliteDatabaseQuery();
        query.setSatelliteNumber(Pattern.compile(satelliteIdentifier));

        for (StkSatelliteDatabaseEntry entry : satelliteDatabase.getEntries(query)) {
            result.add(entry.getTwoLineElementSet());
            break;
        }
//        System.out.println(result);
        return result;
//            throw new DataUnavailableException("TLE data for " + satelliteIdentifier + " could not be found in local SatelliteDatabase");
        }
    }

        /**
     * 获取SolarAzimuthAngle
     * @param step 采样间隔
     * @return
     */
    public SceneReport getSolarAzimuthAngleReport(TimeInterval timeInterval, Duration step){
        //数据已经跟stk的对过了 差不太多  之前测相差太大的原因可能是因为stk用的tle source和这里用的不一样。
        // Compute the vector from the satellite's location to the Sun's center of mass.

        SunCentralBody sun =  CentralBodiesFacet.getFromContext().getSun();
        Point sunCenterOfMassPoint = sun.getFixedFrame().getOrigin();
        VectorTrueDisplacement vectorSatelliteToSun = new VectorTrueDisplacement(getLocationPoint(),sunCenterOfMassPoint);
        DateMotionCollection1<Cartesian> timeIntervalCollection1 = getLocationPoint().getEvaluator().evaluate(timeInterval,step,0);
//        DateMotionCollection1<Cartesian> timeIntervalCollection2 = sunCenterOfMassPoint.getEvaluator().evaluate(timeInterval,Duration.fromMinutes(minutes),0);
        DateMotionCollection1<Cartesian> timeIntervalCollection3 = vectorSatelliteToSun.getEvaluator().evaluate(timeInterval,step,0);
        List<JulianDate> julianDateList = timeIntervalCollection1.getDates();
        List<Cartesian> cartesianList3 = timeIntervalCollection3.getValues();


        SceneReport sceneReport = new SceneReport();
        sceneReport.setType(SceneReportType.Solar_AER);
        sceneReport.setTimeInterval(timeInterval);
        sceneReport.setStep(step);
        sceneReport.setPointNum(julianDateList.size());
        List<ArrayList<String>> data = new ArrayList<>();
        for (int i = 0;i<julianDateList.size();i++){
            //坐标系转换
            ReferenceFrameEvaluator evaluator = GeometryTransformer.getReferenceFrameTransformation(m_earth.getInertialFrame(),new ReferenceFrame(getLocationPoint(),getOrientationAxes()));
            KinematicTransformation transformation = evaluator.evaluate(julianDateList.get(i), 0);
            Cartesian cartesian = transformation.transform(cartesianList3.get(i));
            AzimuthElevationRange azimuthElevationRange = new AzimuthElevationRange(cartesian);

            ArrayList<String> dataRow = new ArrayList<>();
            dataRow.add(julianDateList.get(i).toDateTime().toString());
            dataRow.add(String.valueOf(Trig.radiansToDegrees(azimuthElevationRange.getElevation())));
            dataRow.add(String.valueOf(Trig.radiansToDegrees(azimuthElevationRange.getAzimuth())));
            data.add(dataRow);
        }
        sceneReport.setData(data);
        return sceneReport;
//
//        JSONArray jsonArray = new JSONArray();
//        for (int i=0;i<julianDateList.size();i++){
//            //坐标系转换
//            ReferenceFrameEvaluator evaluator = GeometryTransformer.getReferenceFrameTransformation(m_earth.getInertialFrame(),new ReferenceFrame(getLocationPoint(),getOrientationAxes()));
//            KinematicTransformation transformation = evaluator.evaluate(julianDateList.get(i), 0);
//            Cartesian cartesian = transformation.transform(cartesianList3.get(i));
//            AzimuthElevationRange azimuthElevationRange = new AzimuthElevationRange(cartesian);
//
//            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("time",julianDateList.get(i).toDateTime());
//            jsonObject.put("SOZ",Trig.radiansToDegrees(azimuthElevationRange.getElevation()));
//            jsonObject.put("SOA",Trig.radiansToDegrees(azimuthElevationRange.getAzimuth()));
//            jsonObject.put("satName",getName());
//            jsonArray.add(jsonObject);
//
//        }
//        return jsonArray;
    }

    public SceneReport getJ2000PositionVelocityReport(TimeInterval timeInterval,Duration step){
        DateMotionCollection1 dateMotionCollection1 = propagator.createPoint().getEvaluator().evaluate(timeInterval,step,0);
        List<JulianDate> julianDateList = dateMotionCollection1.getDates();
        List<Cartesian> cartesianList = dateMotionCollection1.getValues();
        SceneReport sceneReport = new SceneReport();
        sceneReport.setType(SceneReportType.J2000PositionVelocity);
        sceneReport.setTimeInterval(timeInterval);
        sceneReport.setStep(step);
        sceneReport.setPointNum(julianDateList.size());
        List<ArrayList<String>> data = new ArrayList<>();
        for (int i = 0;i<julianDateList.size();i++){

            ArrayList<String> dataRow = new ArrayList<>();
            dataRow.add(julianDateList.get(i).toDateTime().toString());
            dataRow.add(String.valueOf(cartesianList.get(i).getX()));
            dataRow.add(String.valueOf(cartesianList.get(i).getY()));
            dataRow.add(String.valueOf(cartesianList.get(i).getZ()));
            data.add(dataRow);
        }
        sceneReport.setData(data);
        return sceneReport;
    }


    public SceneReport getFixedPositionVelocityReport(TimeInterval timeInterval,Duration step){
        Point point = propagator.createPoint();
        PointInReferenceFrame new_point = new PointInReferenceFrame(point,m_earth.getFixedFrame());
        DateMotionCollection1 dateMotionCollection1 = new_point.getEvaluator().evaluate(timeInterval,step,0);
        List<JulianDate> julianDateList = dateMotionCollection1.getDates();
        List<Cartesian> cartesianList = dateMotionCollection1.getValues();
        SceneReport sceneReport = new SceneReport();
        sceneReport.setType(SceneReportType.FixedPositionVelocity);
        sceneReport.setTimeInterval(timeInterval);
        sceneReport.setStep(step);
        sceneReport.setPointNum(julianDateList.size());
        List<ArrayList<String>> data = new ArrayList<>();
        for (int i = 0;i<julianDateList.size();i++){
            ArrayList<String> dataRow = new ArrayList<>();
            dataRow.add(julianDateList.get(i).toDateTime().toString());
            dataRow.add(String.valueOf(cartesianList.get(i).getX()));
            dataRow.add(String.valueOf(cartesianList.get(i).getY()));
            dataRow.add(String.valueOf(cartesianList.get(i).getZ()));
            data.add(dataRow);
        }
        sceneReport.setData(data);
        return sceneReport;
    }
    public SceneReport getLLAPosition(TimeInterval timeInterval,Duration step){
        DateMotionCollection1 dateMotionCollection1 = propagator.createPoint().getEvaluator().evaluate(timeInterval,step,0);
        List<JulianDate> julianDateList = dateMotionCollection1.getDates();
        List<Cartesian> cartesianList = dateMotionCollection1.getValues();
        SceneReport sceneReport = new SceneReport();
        sceneReport.setType(SceneReportType.Solar_AER);
        sceneReport.setTimeInterval(timeInterval);
        sceneReport.setStep(step);
        sceneReport.setPointNum(julianDateList.size());
        List<ArrayList<String>> data = new ArrayList<>();
        for (int i = 0;i<julianDateList.size();i++){
            ArrayList<String> dataRow = new ArrayList<>();
            LongitudeLatitudeRadius longitudeLatitudeRadius = new LongitudeLatitudeRadius(cartesianList.get(i));
            dataRow.add(julianDateList.get(i).toDateTime().toString());
            dataRow.add(String.valueOf(longitudeLatitudeRadius.getLatitude()));
            dataRow.add(String.valueOf(longitudeLatitudeRadius.getLongitude()));
            dataRow.add(String.valueOf(longitudeLatitudeRadius.getRadius()));
            data.add(dataRow);
        }
        sceneReport.setData(data);
        return sceneReport;
    }




    /**
     * 创建星座
     * @param planNumber 平面数
     * @param satelliteNumber 卫星数
     * @param slotOffset
     * @return
     */
    public PlatformCollection createWalkerConstellation(int planNumber, int satelliteNumber, int slotOffset){
        PlatformCollection platformCollection = new PlatformCollection();
        WalkerConstellation walkerConstellation = new WalkerConstellation(WalkerConstellationPattern.DELTA,true,planNumber,satelliteNumber,slotOffset,getModifiedKeplerianElements());
        String propagatorName = getPropagator().getClass().getSimpleName();
        System.out.println(propagatorName);
        ModifiedKeplerianElements modifiedKeplerianElements;
        if (propagatorName.equals("TwoBodyPropagator")) {
            WalkerConstellationResult<TwoBodyPropagator> walkerConstellationResult= walkerConstellation.createTwoBodyPropagator(availableTime.getStart(),m_earth.getInertialFrame());
            for (int i =0;i<planNumber;i++){
                for (int j = 0; j<satelliteNumber; j++){
                    TwoBodyPropagator propagator=walkerConstellationResult.getSatellitePropagator(i,j);
                    modifiedKeplerianElements =  new ModifiedKeplerianElements(new KeplerianElements((propagator).getInitialConditions(),EarthGravitationalModel2008.GravitationalParameter));
                   Satellite satellite = new Satellite(getName()+i+j,propagator,modifiedKeplerianElements,availableTime);

                   platformCollection.add(satellite);
                }
            }
        } else if (propagatorName.equals("J2Propagator")||propagatorName.equals("Sgp4Propagator")) {
            WalkerConstellationResult<J2Propagator> walkerConstellationResult= walkerConstellation.createJ2Propagator(availableTime.getStart(),m_earth.getInertialFrame(), EarthGravitationalModel2008.J2UnnormalizedValue,EarthGravitationalModel2008.SemimajorAxis);
            for (int i =0;i<planNumber;i++){
                for (int j = 0; j<satelliteNumber; j++){
                    J2Propagator propagator=walkerConstellationResult.getSatellitePropagator(i,j);
                    modifiedKeplerianElements =  propagator.getInitialConditions();
                    Satellite satellite = new Satellite(getName()+i+j,propagator,modifiedKeplerianElements,availableTime);
                    platformCollection.add(satellite);
                }
            }
        } else if (propagatorName.equals("J4Propagator")) {
            WalkerConstellationResult<J4Propagator> walkerConstellationResult= walkerConstellation.createJ4Propagator(availableTime.getStart(),m_earth.getInertialFrame(), EarthGravitationalModel2008.J2UnnormalizedValue,EarthGravitationalModel2008.J4UnnormalizedValue,EarthGravitationalModel2008.SemimajorAxis);
            for (int i =0;i<planNumber;i++){
                for (int j = 0; j<satelliteNumber; j++){
                    J4Propagator propagator=walkerConstellationResult.getSatellitePropagator(i,j);
                    modifiedKeplerianElements =  propagator.getInitialConditions();
                    Satellite satellite = new Satellite(getName()+i+j,propagator,modifiedKeplerianElements,availableTime);
                    platformCollection.add(satellite);
                }
            }
        }
        System.out.println(platformCollection);
        System.out.println(platformCollection.size());
        return platformCollection;
    }

    public void exportEphemerisFile(Duration step, File file) {
        MotionEvaluator1<Cartesian> motionEvaluator = propagator.getEvaluator();
        DateMotionCollection1<Cartesian> rawEphemerisData = motionEvaluator.evaluate(availableTime.getStart(),availableTime.getStop(),step, 0, null);
        // The data obtained from the MotionEvaluator is in meters.  Convert to desired units, kilometers in this case.
        DateMotionCollection1<Cartesian> rawEphemerisDataKm = new DateMotionCollection1<>();
        double toKilometers = 1.0 / 1000.0;
        for (int i = 0; i < rawEphemerisData.getCount(); i++) {
            rawEphemerisDataKm.add(rawEphemerisData.getDates().get(i),
                    Cartesian.multiply(rawEphemerisData.getMotions().get(i).getValue(), toKilometers));
        }
        BufferedWriter bufferedWriter = null;
        // Once the raw data has been obtained from the MotionEvaluator, place it into an StkEphemerisFile
        // and specify the appropriate coordinate system.
        StkEphemerisFile.EphemerisTimePos ephemerisData = new StkEphemerisFile.EphemerisTimePos();
        try {

            //需要导出卫星的参考系，因为我现在算的参考系都是用这个算的就先固定写这个 后面如果有别的可能需要修改
            Class clazz = propagator.getClass();
            Method method = clazz.getMethod("getReferenceFrame");
            ephemerisData.setCoordinateSystem((ReferenceFrame) method.invoke(propagator));
            ephemerisData.setEphemerisData(rawEphemerisDataKm);
            StkEphemerisFile ephemerisFile = new StkEphemerisFile();
            ephemerisFile.setData(ephemerisData);

            // Finally, write the StkEphemerisFile out.
            //        try (Writer ephemerisWriter = Files.newBufferedWriter(Paths.get(path), StandardCharsets.US_ASCII)) {
            //            ephemerisFile.writeTo(ephemerisWriter);
            //        }

            bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"), 1024);

            ephemerisFile.writeTo(bufferedWriter);
            bufferedWriter.close();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println(e.getMessage());
        }

    }





}
